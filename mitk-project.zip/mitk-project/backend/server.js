const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
const os = require('os');

const app = express();
const PORT = process.env.PORT || 80;
const JWT_SECRET = 'MITK_SECRET_KEY_2025';

// Get local IP address for network access
function getLocalIP() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                return iface.address;
            }
        }
    }
    return 'localhost';
}

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Paths
const BACKEND_PATH = __dirname;
const FRONTEND_PATH = path.join(BACKEND_PATH, '..', 'frontend');
const DATA_PATH = path.join(BACKEND_PATH, 'data');

// Create directories if they don't exist
if (!fs.existsSync(DATA_PATH)) {
    fs.mkdirSync(DATA_PATH, { recursive: true });
}

// Helper functions
function readData(filename) {
    try {
        const filePath = path.join(DATA_PATH, filename);
        if (fs.existsSync(filePath)) {
            return JSON.parse(fs.readFileSync(filePath, 'utf8'));
        }
        return [];
    } catch (error) {
        console.error(`Error reading ${filename}:`, error.message);
        return [];
    }
}

function writeData(filename, data) {
    try {
        fs.writeFileSync(path.join(DATA_PATH, filename), JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error(`Error writing ${filename}:`, error.message);
        return false;
    }
}

// ========== INITIALIZE DATA ==========

// Students Data - 50 Students
let students = readData('students.json');
if (students.length === 0) {
    const names = ['Abhishek Sanikatta', 'Akash M Naik', 'Akshatha Poojari', 'Ambika', 'Aneesh BS', 'Arun Kumar k', 'Bhoomika B D', 'Deepa', 'Deepa Kamalakar Naik', 'Deepthi B', 'Faiz Khan', 'Gafar H', 'Girija', 'Jyothi U R', 'Kishan M Poojary', 'Kruthika G S', 'Mamatha Y S', 'Manasa DN', 'Mandar Ullas Naik', 'Manoj Kumar L', 'Meghana Bai B S', 'Mehak', 'Nagaveni T N', 'Nandisha M', 'Nikhil Kumar A', 'Pooja D', 'Poojary Roshan', 'Poornesh', 'Prajwal D', 'Preethi', 'Priya L P', 'Rachit Ganapati Naik', 'Raghavendra A S', 'Rahul Gujjar D', 'Rakshita T Naik', 'Rakshitha V R', 'Sagar', 'Sanmitha', 'Shravan', 'Shrisathya', 'Shrishan P', 'Sinchana C R', 'Sunil T', 'Supriya Aravind Sangur', 'Tejashwini Dravid HM', 'Veeresh D', 'Velita Sara Mendonsa', 'Vinay Maritammappa Hullur', 'Yogish D B', 'Zakeerhussen Anwar Sha'];
    for (let i = 0; i < names.length; i++) {
        students.push({
            id: i + 1,
            usn: `4MK25MC${(i + 1).toString().padStart(3, '0')}`,
            name: names[i],
            email: `${names[i].toLowerCase().replace(/ /g, '.')}@mitk.edu.in`,
            phone: `9876543${String(i + 100).slice(1)}`,
            semester: 2,
            cgpa: 0,
            fee_status: 'Pending',
            password: 'student123',
            guardian: names[i].split(' ')[0],
            guardian_phone: `9876543${String(i + 100).slice(1)}`,
            address: 'Kundapura, Karnataka',
            joining_year: 2025
        });
    }
    writeData('students.json', students);
}

// Faculty Data
let faculty = readData('faculty.json');
if (faculty.length === 0) {
    faculty = [
        { id: 1, name: 'Dr. T. Nandhini', email: 'nandhini@mitk.edu.in', password: 'faculty123', department: 'MCA', subjects: ['Advanced Java', 'Software Engineering'] },
        { id: 2, name: 'Mr. Prasanna Kumara', email: 'prasanna@mitk.edu.in', password: 'faculty123', department: 'MCA', subjects: ['Python Programming', 'Machine Learning'] },
        { id: 3, name: 'Ms. Ankitha N Bhandary', email: 'ankitha@mitk.edu.in', password: 'faculty123', department: 'MCA', subjects: ['Web Technologies', 'ReactJS'] },
        { id: 4, name: 'Ms. Navyashree', email: 'navya@mitk.edu.in', password: 'faculty123', department: 'MCA', subjects: ['Database Management Systems', 'SQL'] }
    ];
    writeData('faculty.json', faculty);
}

// Marks Data
let marks = readData('marks.json');
if (marks.length === 0) {
    marks = [];
    writeData('marks.json', marks);
}

// Attendance Data
let attendance = readData('attendance.json');
if (attendance.length === 0) {
    attendance = [];
    writeData('attendance.json', attendance);
}

// Fees Data
let fees = readData('fees.json');
if (fees.length === 0) {
    for (let i = 0; i < students.length; i++) {
        fees.push({
            id: i + 1,
            usn: students[i].usn,
            semester: 2,
            total_fee: 50000,
            paid: 0,
            due: 50000,
            last_date: '2025-06-30'
        });
    }
    writeData('fees.json', fees);
}

// Fee Payments Data
let feePayments = readData('fee_payments.json');
if (feePayments.length === 0) {
    feePayments = [];
    writeData('fee_payments.json', feePayments);
}

// Notices Data
let notices = readData('notices.json');
if (notices.length === 0) {
    notices = [
        { id: 1, title: '📢 Fee Payment Deadline', content: 'Last date for semester fee payment is 30th June 2025. Late fee of ₹500 will be charged.', category: 'Finance', priority: 'Urgent', date: '2025-05-20', active: true },
        { id: 2, title: '📝 Internal Assessment Schedule', content: 'IA-2 examinations will be held from 15th June to 20th June 2025.', category: 'Exam', priority: 'High', date: '2025-05-18', active: true }
    ];
    writeData('notices.json', notices);
}

// Applications Data
let applications = readData('applications.json');
if (applications.length === 0) {
    applications = [
        { id: 1, app_no: 'APP2025001', name: 'Ramesh Kumar', email: 'ramesh@email.com', phone: '9876543210', course: 'MCA', status: 'Pending', date: '2025-05-15' }
    ];
    writeData('applications.json', applications);
}

// Timetable Data for Semester 2
let timetable = readData('timetable.json');
if (timetable.length === 0) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const subjects = ['Advanced Java', 'Python Programming', 'Web Technologies', 'Database Management Systems'];
    const facultyNames = ['Dr. T. Nandhini', 'Mr. Prasanna Kumara', 'Ms. Ankitha N Bhandary', 'Ms. Navyashree'];
    const rooms = ['Room 101', 'Lab 01', 'Lab 02', 'Room 102'];
    for (let d = 0; d < days.length; d++) {
        for (let i = 0; i < subjects.length; i++) {
            timetable.push({
                id: timetable.length + 1,
                semester: 2,
                day: days[d],
                time: `${9 + i}:00-${10 + i}:30`,
                subject: subjects[i],
                code: `MCA20${i + 1}`,
                faculty: facultyNames[i],
                room: rooms[i]
            });
        }
    }
    writeData('timetable.json', timetable);
}

// ========== AUTHENTICATION ==========

// Student Login
app.post('/api/auth/student/login', (req, res) => {
    const { usn, password } = req.body;
    const student = students.find(s => s.usn === usn && s.password === password);
    
    if (!student) {
        return res.status(401).json({ error: 'Invalid USN or password' });
    }
    
    const token = jwt.sign(
        { usn: student.usn, name: student.name, role: 'student', semester: student.semester },
        JWT_SECRET,
        { expiresIn: '7d' }
    );
    
    res.json({
        success: true,
        token: token,
        user: {
            usn: student.usn,
            name: student.name,
            role: 'student',
            semester: student.semester,
            email: student.email
        }
    });
});

// Admin Login
app.post('/api/auth/admin/login', (req, res) => {
    const { email, password } = req.body;
    
    if (email === 'admin@mitk.edu.in' && password === 'admin123') {
        const token = jwt.sign(
            { email: email, role: 'admin' },
            JWT_SECRET,
            { expiresIn: '7d' }
        );
        
        res.json({
            success: true,
            token: token,
            user: {
                email: email,
                role: 'admin'
            }
        });
    } else {
        res.status(401).json({ error: 'Invalid credentials' });
    }
});

// Faculty Login
app.post('/api/auth/faculty/login', (req, res) => {
    const { email, password } = req.body;
    
    const freshFaculty = readData('faculty.json');
    const facultyMember = freshFaculty.find(f => f.email === email && f.password === password);
    
    if (!facultyMember) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign(
        { id: facultyMember.id, email: facultyMember.email, name: facultyMember.name, role: 'faculty', subjects: facultyMember.subjects },
        JWT_SECRET,
        { expiresIn: '7d' }
    );
    
    res.json({
        success: true,
        token: token,
        user: {
            id: facultyMember.id,
            name: facultyMember.name,
            email: facultyMember.email,
            role: 'faculty',
            subjects: facultyMember.subjects
        }
    });
});

// ========== STUDENT ROUTES ==========

// Get Dashboard
app.get('/api/student/dashboard', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const student = students.find(s => s.usn === decoded.usn);
        
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }
        
        const studentFees = fees.find(f => f.usn === decoded.usn);
        const studentAttendance = attendance.filter(a => a.usn === decoded.usn);
        let totalAttendance = 0;
        if (studentAttendance.length > 0) {
            totalAttendance = Math.round(studentAttendance.reduce((sum, a) => sum + a.percentage, 0) / studentAttendance.length);
        }
        
        res.json({
            student: student,
            attendance: totalAttendance,
            fee_due: studentFees ? studentFees.due : 50000,
            notices: notices.filter(n => n.active).slice(0, 5)
        });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Marks
app.get('/api/student/marks', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const studentMarks = marks.filter(m => m.usn === decoded.usn);
        res.json({ marks: studentMarks });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Attendance
app.get('/api/student/attendance', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const studentAttendance = attendance.filter(a => a.usn === decoded.usn);
        res.json({ attendance: studentAttendance });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Fees
app.get('/api/student/fees', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        let studentFees = fees.find(f => f.usn === decoded.usn);
        
        if (!studentFees) {
            const student = students.find(s => s.usn === decoded.usn);
            studentFees = {
                id: fees.length + 1,
                usn: decoded.usn,
                semester: student?.semester || 2,
                total_fee: 50000,
                paid: 0,
                due: 50000,
                last_date: '2025-06-30'
            };
            fees.push(studentFees);
            writeData('fees.json', fees);
        }
        
        res.json({ fees: studentFees });
    } catch (error) {
        console.error('Get fees error:', error);
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Pay Fee
app.post('/api/student/pay-fee', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const { amount, payment_mode, transaction_id } = req.body;
        const receipt_no = `MITK-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
        
        const studentFeeIndex = fees.findIndex(f => f.usn === decoded.usn);
        if (studentFeeIndex !== -1) {
            fees[studentFeeIndex].paid += parseFloat(amount);
            fees[studentFeeIndex].due = fees[studentFeeIndex].total_fee - fees[studentFeeIndex].paid;
            writeData('fees.json', fees);
        }
        
        let feePayments = readData('fee_payments.json');
        const newPayment = {
            id: feePayments.length + 1,
            receipt_no: receipt_no,
            usn: decoded.usn,
            amount: parseFloat(amount),
            payment_mode: payment_mode,
            transaction_id: transaction_id || `TXN${Date.now()}`,
            payment_date: new Date().toISOString(),
            status: 'Success'
        };
        feePayments.push(newPayment);
        writeData('fee_payments.json', feePayments);
        
        res.json({ 
            success: true, 
            receipt_no: receipt_no,
            amount: amount,
            payment_mode: payment_mode,
            message: 'Payment successful' 
        });
    } catch (error) {
        console.error('Payment error:', error);
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Student Payment History
app.get('/api/student/payments', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const feePayments = readData('fee_payments.json');
        const studentPayments = feePayments.filter(p => p.usn === decoded.usn);
        res.json({ payments: studentPayments });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Student Timetable
app.get('/api/student/timetable', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const studentTimetable = timetable.filter(t => t.semester === decoded.semester);
        res.json({ timetable: studentTimetable });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Profile
app.get('/api/student/profile', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const student = students.find(s => s.usn === decoded.usn);
        res.json({ profile: student });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

// ========== FACULTY ROUTES ==========

// Faculty Dashboard
app.get('/api/faculty/dashboard', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        res.json({
            total_students: students.length,
            subjects: decoded.subjects || [],
            today_classes: decoded.subjects?.length || 0
        });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Faculty Subjects
app.get('/api/faculty/subjects', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        res.json({ subjects: decoded.subjects || [] });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Students for a Subject
app.get('/api/faculty/students', (req, res) => {
    const studentList = students.map(s => ({
        usn: s.usn,
        name: s.name,
        semester: s.semester,
        email: s.email
    }));
    
    res.json({ students: studentList });
});

// Get Attendance for a date
app.get('/api/faculty/attendance/:date', (req, res) => {
    const { date } = req.params;
    const { subject } = req.query;
    
    const existingAttendance = attendance.filter(a => 
        a.date === date && a.subject === subject
    );
    
    res.json({ attendance: existingAttendance });
});

// Save Attendance
app.post('/api/faculty/save-attendance', (req, res) => {
    const { subject, date, attendance: attendanceList } = req.body;
    
    const otherAttendance = attendance.filter(a => 
        !(a.subject === subject && a.date === date)
    );
    
    const newAttendance = attendanceList.map(a => ({
    id: attendance.length + Math.random(),
    usn: a.usn,
    subject: a.subject,
    date: a.date,
    classHour: a.classHour || '',   // Added
    status: a.status,
    remarks: a.remarks || '',
    semester: students.find(s => s.usn === a.usn)?.semester || 2,
    total: 1,
    attended: a.status === 'Present' ? 1 : 0,
    percentage: a.status === 'Present' ? 100 : 0
}));
    const updatedAttendance = [...otherAttendance, ...newAttendance];
    attendance.length = 0;
    updatedAttendance.forEach(a => attendance.push(a));
    writeData('attendance.json', attendance);
    
    res.json({ success: true, message: 'Attendance saved' });
});
// ========== FACULTY MARKS ROUTES - FIXED ==========

// Get Students for a Subject (Faculty) - FIXED
app.get('/api/faculty/students', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        jwt.verify(token, JWT_SECRET);
        // Return all students without subject filter (for marks panel)
        const studentList = students.map(s => ({
            usn: s.usn,
            name: s.name,
            semester: s.semester,
            email: s.email
        }));
        res.json({ students: studentList });
    } catch (error) {
        console.error('Faculty students error:', error);
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Marks for a subject (Faculty) - FIXED
app.get('/api/faculty/marks', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        jwt.verify(token, JWT_SECRET);
        const { subject, type } = req.query;
        const field = type === 'ia1' ? 'ia1' : 'ia2';
        
        // Filter marks by subject
        const subjectMarks = marks.filter(m => m.subject === subject).map(m => ({
            usn: m.usn,
            marks: m[field] || 0
        }));
        
        res.json({ marks: subjectMarks });
    } catch (error) {
        console.error('Faculty marks error:', error);
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Save Marks (Faculty) - FIXED
app.post('/api/faculty/save-marks', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        jwt.verify(token, JWT_SECRET);
        const { subject, type, marks: marksList } = req.body;
        const field = type === 'ia1' ? 'ia1' : 'ia2';
        
        for (const m of marksList) {
            const existingIndex = marks.findIndex(mark => mark.usn === m.usn && mark.subject === subject);
            if (existingIndex !== -1) {
                marks[existingIndex][field] = m.marks;
                marks[existingIndex].total = (marks[existingIndex].ia1 || 0) + (marks[existingIndex].ia2 || 0);
                
                // Calculate grade
                const total = marks[existingIndex].total;
                if (total >= 45) marks[existingIndex].grade = 'A+';
                else if (total >= 40) marks[existingIndex].grade = 'A';
                else if (total >= 35) marks[existingIndex].grade = 'B+';
                else if (total >= 30) marks[existingIndex].grade = 'B';
                else if (total >= 25) marks[existingIndex].grade = 'C';
                else marks[existingIndex].grade = 'F';
            } else {
                // Create new marks record
                const total = parseInt(m.marks) || 0;
                let grade = 'F';
                if (total >= 23) grade = 'A+';
                else if (total >= 20) grade = 'A';
                else if (total >= 17) grade = 'B+';
                else if (total >= 14) grade = 'B';
                else if (total >= 10) grade = 'C';
                
                marks.push({
                    id: marks.length + 1,
                    usn: m.usn,
                    subject: subject,
                    semester: 2,
                    code: subject.substring(0, 6).toUpperCase(),
                    ia1: type === 'ia1' ? m.marks : 0,
                    ia2: type === 'ia2' ? m.marks : 0,
                    total: total,
                    grade: grade
                });
            }
        }
        
        writeData('marks.json', marks);
        res.json({ success: true, message: 'Marks saved successfully' });
    } catch (error) {
        console.error('Save marks error:', error);
        res.status(401).json({ error: 'Invalid token' });
    }
});

// Get Faculty Timetable (filtered by faculty name)
app.get('/api/faculty/timetable', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'No token' });
    
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const facultyName = decoded.name;
        const facultyTimetable = timetable.filter(t => t.faculty === facultyName);
        res.json({ timetable: facultyTimetable });
    } catch (error) {
        console.error('Faculty timetable error:', error);
        res.status(401).json({ error: 'Invalid token' });
    }
});




// ========== ENHANCED FACULTY ATTENDANCE ENDPOINTS ==========

// Get total classes for a subject
app.get('/api/faculty/total-classes', (req, res) => {
    const { subject } = req.query;
    let subjectData = timetable.find(t => t.subject === subject);
    if (!subjectData) {
        subjectData = { total_classes: 0 };
    }
    res.json({ total_classes: subjectData?.total_classes || 0 });
});

// Update total classes
app.post('/api/faculty/total-classes', (req, res) => {
    const { subject, total_classes } = req.body;
    const index = timetable.findIndex(t => t.subject === subject);
    if (index !== -1) {
        timetable[index].total_classes = total_classes;
    } else {
        timetable.push({ 
            id: timetable.length + 1,
            subject: subject, 
            total_classes: total_classes,
            semester: 2,
            day: 'Monday',
            time: '09:00-10:30',
            faculty: 'Dr. T. Nandhini',
            room: 'Room 101'
        });
    }
    writeData('timetable.json', timetable);
    res.json({ success: true, message: 'Total classes updated' });
});

// Get attendance summary for a subject
app.get('/api/faculty/attendance-summary', (req, res) => {
    const { subject } = req.query;
    const summary = attendance.filter(a => a.subject === subject);
    
    const studentSummary = [];
    const studentsList = students.map(s => s.usn);
    
    studentsList.forEach(usn => {
        const studentAttendance = summary.filter(a => a.usn === usn);
        const totalClasses = studentAttendance.length;
        const attendedClasses = studentAttendance.filter(a => a.status === 'Present').length;
        const percentage = totalClasses > 0 ? ((attendedClasses / totalClasses) * 100).toFixed(1) : 0;
        
        studentSummary.push({
            usn: usn,
            name: students.find(s => s.usn === usn)?.name || '',
            total_classes: totalClasses,
            attended: attendedClasses,
            percentage: percentage
        });
    });
    
    res.json({ summary: studentSummary });
});

// Get attendance history for charts
app.get('/api/faculty/attendance-history', (req, res) => {
    const { subject } = req.query;
    const history = attendance.filter(a => a.subject === subject).sort((a, b) => new Date(a.date) - new Date(b.date));
    res.json({ attendance: history });
});

// Get attendance report for export
app.get('/api/faculty/attendance-report', (req, res) => {
    const { subject, startDate, endDate } = req.query;
    let filteredAttendance = attendance.filter(a => a.subject === subject);
    
    if (startDate) {
        filteredAttendance = filteredAttendance.filter(a => a.date >= startDate);
    }
    if (endDate) {
        filteredAttendance = filteredAttendance.filter(a => a.date <= endDate);
    }
    
    const report = [];
    const studentsList = students.map(s => ({ usn: s.usn, name: s.name, semester: s.semester }));
    
    studentsList.forEach(student => {
        const studentAttendance = filteredAttendance.filter(a => a.usn === student.usn);
        const presentCount = studentAttendance.filter(a => a.status === 'Present').length;
        const absentCount = studentAttendance.filter(a => a.status === 'Absent').length;
        const leaveCount = studentAttendance.filter(a => a.status === 'Leave').length;
        const total = studentAttendance.length;
        const percentage = total > 0 ? ((presentCount / total) * 100).toFixed(1) : 0;
        
        report.push({
            usn: student.usn,
            name: student.name,
            semester: student.semester,
            present: presentCount,
            absent: absentCount,
            leave: leaveCount,
            total_classes: total,
            percentage: percentage
        });
    });
    
    res.json({ report });
});

// ========== ADMIN ROUTES ==========

// Get All Students
app.get('/api/admin/students', (req, res) => {
    res.json({ students: students });
});

// Add Student
app.post('/api/admin/students', (req, res) => {
    const { usn, name, email, phone, semester, guardian, guardian_phone, address } = req.body;
    
    if (students.find(s => s.usn === usn)) {
        return res.status(400).json({ error: 'USN already exists' });
    }
    
    const newStudent = {
        id: students.length + 1,
        usn: usn,
        name: name,
        email: email,
        phone: phone,
        semester: parseInt(semester),
        cgpa: 0,
        fee_status: 'Pending',
        password: 'student123',
        guardian: guardian || '',
        guardian_phone: guardian_phone || '',
        address: address || '',
        joining_year: new Date().getFullYear()
    };
    
    students.push(newStudent);
    writeData('students.json', students);
    
    const newFee = {
        id: fees.length + 1,
        usn: usn,
        semester: parseInt(semester),
        total_fee: 50000,
        paid: 0,
        due: 50000,
        last_date: '2025-06-30'
    };
    fees.push(newFee);
    writeData('fees.json', fees);
    
    res.json({ success: true, message: 'Student added successfully with fee record' });
});

// Update Student
app.put('/api/admin/students/:usn', (req, res) => {
    const { usn } = req.params;
    const { name, email, phone, semester, cgpa, fee_status, guardian, guardian_phone, address } = req.body;
    
    const index = students.findIndex(s => s.usn === usn);
    if (index === -1) {
        return res.status(404).json({ error: 'Student not found' });
    }
    
    students[index] = { ...students[index], name, email, phone, semester, cgpa, fee_status, guardian, guardian_phone, address };
    writeData('students.json', students);
    res.json({ success: true, message: 'Student updated successfully' });
});

// Delete Student
app.delete('/api/admin/students/:usn', (req, res) => {
    const { usn } = req.params;
    const index = students.findIndex(s => s.usn === usn);
    if (index === -1) {
        return res.status(404).json({ error: 'Student not found' });
    }
    
    const feeIndex = fees.findIndex(f => f.usn === usn);
    if (feeIndex !== -1) {
        fees.splice(feeIndex, 1);
        writeData('fees.json', fees);
    }
    
    students.splice(index, 1);
    writeData('students.json', students);
    res.json({ success: true, message: 'Student deleted successfully' });
});

// ========== FACULTY MANAGEMENT (ADMIN) ==========

// Get all faculty
app.get('/api/admin/faculty', (req, res) => {
    const facultyData = readData('faculty.json');
    res.json({ faculty: facultyData });
});

// Add faculty
app.post('/api/admin/faculty', (req, res) => {
    const { name, email, department, password, subjects } = req.body;
    let facultyData = readData('faculty.json');
    
    if (facultyData.find(f => f.email === email)) {
        return res.status(400).json({ error: 'Email already exists' });
    }
    
    const newFaculty = {
        id: facultyData.length + 1,
        name: name,
        email: email,
        password: password || 'faculty123',
        department: department || 'MCA',
        subjects: subjects || []
    };
    
    facultyData.push(newFaculty);
    writeData('faculty.json', facultyData);
    
    console.log(`✅ New faculty added: ${name} (${email})`);
    
    res.json({ success: true, message: 'Faculty added successfully' });
});

// Update faculty
app.put('/api/admin/faculty/:id', (req, res) => {
    const { id } = req.params;
    const { name, email, department, subjects } = req.body;
    let facultyData = readData('faculty.json');
    
    const index = facultyData.findIndex(f => f.id === parseInt(id));
    if (index === -1) {
        return res.status(404).json({ error: 'Faculty not found' });
    }
    
    facultyData[index] = { ...facultyData[index], name, email, department, subjects };
    writeData('faculty.json', facultyData);
    
    res.json({ success: true, message: 'Faculty updated successfully' });
});

// Delete faculty
app.delete('/api/admin/faculty/:id', (req, res) => {
    const { id } = req.params;
    let facultyData = readData('faculty.json');
    
    const index = facultyData.findIndex(f => f.id === parseInt(id));
    if (index === -1) {
        return res.status(404).json({ error: 'Faculty not found' });
    }
    
    facultyData.splice(index, 1);
    writeData('faculty.json', facultyData);
    
    res.json({ success: true, message: 'Faculty deleted successfully' });
});

// Get All Applications
app.get('/api/admin/applications', (req, res) => {
    res.json({ applications: applications });
});

// Update Application Status
app.put('/api/admin/applications/:id', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const appIndex = applications.findIndex(a => a.id === parseInt(id));
    
    if (appIndex === -1) {
        return res.status(404).json({ error: 'Application not found' });
    }
    
    applications[appIndex].status = status;
    writeData('applications.json', applications);
    res.json({ success: true, message: 'Status updated' });
});

// Delete Application
app.delete('/api/admin/applications/:id', (req, res) => {
    const { id } = req.params;
    const index = applications.findIndex(a => a.id === parseInt(id));
    if (index === -1) {
        return res.status(404).json({ error: 'Application not found' });
    }
    
    applications.splice(index, 1);
    writeData('applications.json', applications);
    res.json({ success: true, message: 'Application deleted' });
});

// Add Application
app.post('/api/admin/applications', (req, res) => {
    const { name, email, phone, course } = req.body;
    const newApp = {
        id: applications.length + 1,
        app_no: `APP${Date.now()}`,
        name: name,
        email: email,
        phone: phone,
        course: course || 'MCA',
        status: 'Pending',
        date: new Date().toISOString().split('T')[0]
    };
    applications.push(newApp);
    writeData('applications.json', applications);
    res.json({ success: true, message: 'Application added' });
});

// Post Notice
app.post('/api/admin/notices', (req, res) => {
    const { title, content, category, priority } = req.body;
    const newNotice = {
        id: notices.length + 1,
        title: title,
        content: content,
        category: category || 'General',
        priority: priority || 'Normal',
        date: new Date().toISOString().split('T')[0],
        active: true
    };
    notices.unshift(newNotice);
    writeData('notices.json', notices);
    res.json({ success: true, message: 'Notice posted' });
});

// Delete Notice
app.delete('/api/admin/notices/:id', (req, res) => {
    const { id } = req.params;
    const index = notices.findIndex(n => n.id === parseInt(id));
    if (index === -1) {
        return res.status(404).json({ error: 'Notice not found' });
    }
    
    notices.splice(index, 1);
    writeData('notices.json', notices);
    res.json({ success: true, message: 'Notice deleted' });
});

// Get All Notices
app.get('/api/admin/notices', (req, res) => {
    res.json({ notices: notices });
});

// Get Admin Stats
app.get('/api/admin/stats', (req, res) => {
    const totalStudents = students.length;
    const pendingApps = applications.filter(a => a.status === 'Pending' || a.status === 'Under Review').length;
    const totalFees = fees.reduce((sum, f) => sum + (f.paid || 0), 0);
    const activeNotices = notices.filter(n => n.active).length;
    const facultyData = readData('faculty.json');
    
    res.json({
        total_students: totalStudents,
        pending_applications: pendingApps,
        total_fees: totalFees,
        active_notices: activeNotices,
        total_faculty: facultyData.length
    });
});

// Get all fees for admin
app.get('/api/admin/fees', (req, res) => {
    res.json({ fees: fees });
});

// Get all payments for admin
app.get('/api/admin/payments', (req, res) => {
    const feePayments = readData('fee_payments.json');
    res.json({ payments: feePayments });
});

// Get timetable for admin
app.get('/api/admin/timetable', (req, res) => {
    const semester = parseInt(req.query.semester) || 2;
    const semesterTimetable = timetable.filter(t => t.semester === semester);
    res.json({ timetable: semesterTimetable });
});

// Save timetable
app.post('/api/admin/timetable', (req, res) => {
    const { semester, timetable: newTimetable } = req.body;
    
    const otherTimetable = timetable.filter(t => t.semester !== parseInt(semester));
    const updatedTimetable = [...otherTimetable, ...newTimetable.map(t => ({ ...t, semester: parseInt(semester) }))];
    
    timetable.length = 0;
    updatedTimetable.forEach(t => timetable.push(t));
    writeData('timetable.json', timetable);
    
    res.json({ success: true, message: 'Timetable saved' });
});

// ========== SERVE FRONTEND ==========

app.get('/', (req, res) => {
    res.sendFile(path.join(FRONTEND_PATH, 'index.html'));
});

app.get('/pages/student/:page', (req, res) => {
    const pagePath = path.join(FRONTEND_PATH, 'pages', 'student', req.params.page);
    if (fs.existsSync(pagePath)) {
        res.sendFile(pagePath);
    } else {
        res.status(404).send('Page not found');
    }
});

app.get('/pages/admin/:page', (req, res) => {
    const pagePath = path.join(FRONTEND_PATH, 'pages', 'admin', req.params.page);
    if (fs.existsSync(pagePath)) {
        res.sendFile(pagePath);
    } else {
        res.status(404).send('Page not found');
    }
});

app.get('/pages/faculty/:page', (req, res) => {
    const pagePath = path.join(FRONTEND_PATH, 'pages', 'faculty', req.params.page);
    if (fs.existsSync(pagePath)) {
        res.sendFile(pagePath);
    } else {
        res.status(404).send('Page not found');
    }
});

app.get('/css/:file', (req, res) => {
    const cssPath = path.join(FRONTEND_PATH, 'css', req.params.file);
    if (fs.existsSync(cssPath)) {
        res.sendFile(cssPath);
    } else {
        res.status(404).send('CSS not found');
    }
});

// ========== START SERVER ==========
app.listen(PORT, '0.0.0.0', () => {
    const localIP = getLocalIP();
    console.log('\n========================================');
    console.log('🎓 MITK Moodlakatte Institute of Technology');
    console.log('✅ Student Management System Running');
    console.log('========================================');
    console.log(`📍 Local Access: http://localhost`);
    console.log(`📍 Network Access: http://${localIP}`);
    console.log('\n🔐 Login Credentials:');
    console.log('   Admin: admin@mitk.edu.in / admin123');
    console.log('   Student: 4MK25MC001 / student123');
    console.log('   Faculty: nandhini@mitk.edu.in / faculty123');
    console.log('   Faculty: prasanna@mitk.edu.in / faculty123');
    console.log('   Faculty: ankitha@mitk.edu.in / faculty123');
    console.log('   Faculty: navya@mitk.edu.in / faculty123');
    console.log('========================================\n');
    console.log(`📢 Share this URL with faculty & students:`);
    console.log(`   http://${localIP}`);
    console.log('========================================\n');
});