package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import db.DBConnection;
import model.Faculty;

public class FacultyDAO {

    public boolean addFaculty(Faculty faculty) {

        try {

            Connection con = DBConnection.getConnection();

            String sql =
                    "INSERT INTO faculty(name,email) VALUES(?,?)";

            PreparedStatement pst =
                    con.prepareStatement(sql);

            pst.setString(1, faculty.getName());
            pst.setString(2, faculty.getEmail());

            int rows = pst.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}