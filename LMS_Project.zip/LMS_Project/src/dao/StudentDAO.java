package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import db.DBConnection;
import model.Student;

public class StudentDAO {

    public boolean addStudent(Student student) {

        try {

            Connection con = DBConnection.getConnection();

            String sql =
                    "INSERT INTO students(name,email,semester) VALUES(?,?,?)";

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, student.getName());
            pst.setString(2, student.getEmail());
            pst.setInt(3, student.getSemester());

            int rows = pst.executeUpdate();

            System.out.println("Rows Inserted = " + rows);

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}