package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import db.DBConnection;
import model.Course;

public class CourseDAO {

    public boolean addCourse(Course course) {

        try {

            Connection con = DBConnection.getConnection();

            String sql =
                    "INSERT INTO courses(course_name) VALUES(?)";

            PreparedStatement pst =
                    con.prepareStatement(sql);

            pst.setString(1, course.getCourseName());

            int rows = pst.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}