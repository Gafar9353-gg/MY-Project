package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import db.DBConnection;
import model.Assignment;

public class AssignmentDAO {

    public boolean addAssignment(Assignment assignment) {

        try {

            Connection con = DBConnection.getConnection();

            String sql =
                "INSERT INTO assignments(title,description) VALUES(?,?)";

            PreparedStatement pst =
                con.prepareStatement(sql);

            pst.setString(1, assignment.getTitle());
            pst.setString(2, assignment.getDescription());

            int rows = pst.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}