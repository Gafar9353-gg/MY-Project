package model;

public class Student {

    private String name;
    private String email;
    private int semester;

    public Student(String name, String email, int semester) {
        this.name = name;
        this.email = email;
        this.semester = semester;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getSemester() {
        return semester;
    }
}