package model;

public class Faculty {

    private String name;
    private String email;

    public Faculty(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}