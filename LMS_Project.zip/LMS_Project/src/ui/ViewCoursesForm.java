package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

import db.DBConnection;

public class ViewCoursesForm extends JFrame {

    JTable table;
    DefaultTableModel model;

    public ViewCoursesForm() {

        setTitle("View Courses");
        setSize(600, 400);

        model = new DefaultTableModel();

        model.addColumn("Course ID");
        model.addColumn("Course Name");

        table = new JTable(model);

        JScrollPane scrollPane =
                new JScrollPane(table);

        add(scrollPane);

        loadCourses();

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadCourses() {

        try {

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT * FROM courses";

            PreparedStatement pst =
                    con.prepareStatement(sql);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                model.addRow(new Object[]{
                        rs.getInt("course_id"),
                        rs.getString("course_name")
                });
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}