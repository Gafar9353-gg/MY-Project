package ui;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class ViewGradesForm extends JFrame {
    
    private JTable gradesTable;
    private DefaultTableModel tableModel;
    private JLabel lblGPA, lblTotalCredits, lblStatus;
    private int studentId = 1; // This should come from login session
    
    public ViewGradesForm() {
        setTitle("My Grades & Performance");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 248, 255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Header
        JLabel lblTitle = new JLabel("📊 Academic Performance Report", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setForeground(new Color(46, 204, 113));
        mainPanel.add(lblTitle, BorderLayout.NORTH);
        
        // Stats Panel
        JPanel statsPanel = createStatsPanel();
        mainPanel.add(statsPanel, BorderLayout.CENTER);
        
        // Grades Table
        createGradesTable();
        JScrollPane scrollPane = new JScrollPane(gradesTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Course-wise Grades"));
        mainPanel.add(scrollPane, BorderLayout.SOUTH);
        
        loadGrades();
        
        add(mainPanel);
        setVisible(true);
    }
    
    private JPanel createStatsPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 3, 20, 20));
        panel.setBackground(new Color(240, 248, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // GPA Card
        JPanel gpaCard = createStatCard("📈 Current GPA", "0.00", new Color(46, 204, 113));
        lblGPA = (JLabel) gpaCard.getComponent(1);
        panel.add(gpaCard);
        
        // Credits Card
        JPanel creditsCard = createStatCard("🎓 Total Credits", "0", new Color(46, 134, 171));
        lblTotalCredits = (JLabel) creditsCard.getComponent(1);
        panel.add(creditsCard);
        
        // Status Card
        JPanel statusCard = createStatCard("✅ Academic Status", "Good Standing", new Color(241, 196, 15));
        lblStatus = (JLabel) statusCard.getComponent(1);
        panel.add(statusCard);
        
        return panel;
    }
    
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 2),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        JLabel lblTitle = new JLabel(title, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 14));
        
        JLabel lblValue = new JLabel(value, SwingConstants.CENTER);
        lblValue.setFont(new Font("Arial", Font.BOLD, 28));
        lblValue.setForeground(color);
        
        card.add(lblTitle, BorderLayout.NORTH);
        card.add(lblValue, BorderLayout.CENTER);
        
        return card;
    }
    
    private void createGradesTable() {
        String[] columns = {"Course Code", "Course Name", "Assignment", "Grade", "Status", "Remarks"};
        tableModel = new DefaultTableModel(columns, 0);
        gradesTable = new JTable(tableModel);
        gradesTable.setRowHeight(35);
        
        // Set column widths
        gradesTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        gradesTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        gradesTable.getColumnModel().getColumn(2).setPreferredWidth(150);
        gradesTable.getColumnModel().getColumn(3).setPreferredWidth(80);
        gradesTable.getColumnModel().getColumn(4).setPreferredWidth(100);
        gradesTable.getColumnModel().getColumn(5).setPreferredWidth(150);
    }
    
    private void loadGrades() {
        tableModel.setRowCount(0);
        
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT c.course_id, c.course_name, a.title as assignment_title, " +
                        "s.grade, s.status, " +
                        "CASE " +
                        "   WHEN CAST(s.grade AS DECIMAL) >= 90 THEN 'Excellent' " +
                        "   WHEN CAST(s.grade AS DECIMAL) >= 75 THEN 'Good' " +
                        "   WHEN CAST(s.grade AS DECIMAL) >= 60 THEN 'Satisfactory' " +
                        "   WHEN CAST(s.grade AS DECIMAL) >= 40 THEN 'Pass' " +
                        "   ELSE 'Needs Improvement' " +
                        "END as remarks " +
                        "FROM submissions s " +
                        "JOIN assignments a ON s.assignment_id = a.assignment_id " +
                        "JOIN courses c ON a.course_id = c.course_id " +
                        "WHERE s.student_id = ? AND s.grade IS NOT NULL";
            
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, studentId);
            ResultSet rs = pst.executeQuery();
            
            double totalGrade = 0;
            int gradeCount = 0;
            
            while (rs.next()) {
                String grade = rs.getString("grade");
                double gradeValue = 0;
                if (grade != null && !grade.isEmpty()) {
                    try {
                        gradeValue = Double.parseDouble(grade);
                        totalGrade += gradeValue;
                        gradeCount++;
                    } catch (NumberFormatException e) {}
                }
                
                tableModel.addRow(new Object[]{
                    "C" + rs.getString("course_id"),
                    rs.getString("course_name"),
                    rs.getString("assignment_title"),
                    grade != null ? grade + "%" : "N/A",
                    rs.getString("status"),
                    rs.getString("remarks")
                });
            }
            
            // Calculate GPA (assuming 100-point scale)
            if (gradeCount > 0) {
                double average = totalGrade / gradeCount;
                double gpa = (average / 100) * 4.0;
                lblGPA.setText(String.format("%.2f", gpa));
                
                // Set status based on GPA
                if (gpa >= 3.5) lblStatus.setText("🎉 Excellent");
                else if (gpa >= 3.0) lblStatus.setText("👍 Good Standing");
                else if (gpa >= 2.0) lblStatus.setText("⚠️ Satisfactory");
                else lblStatus.setText("🔴 Academic Probation");
            }
            
            lblTotalCredits.setText(String.valueOf(gradeCount * 3) + " (Estimated)");
            
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}