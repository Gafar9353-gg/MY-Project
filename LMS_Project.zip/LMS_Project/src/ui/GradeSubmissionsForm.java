package ui;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class GradeSubmissionsForm extends JFrame {
    
    private JTable submissionsTable;
    private DefaultTableModel tableModel;
    private JComboBox<String> cmbCourse;
    private JComboBox<String> cmbAssignment;
    private JButton btnLoadSubmissions, btnSaveGrade;
    private JLabel lblStatus;
    
    public GradeSubmissionsForm() {
        setTitle("Grade Student Submissions");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 248, 255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Top Panel - Filters
        JPanel topPanel = createFilterPanel();
        mainPanel.add(topPanel, BorderLayout.NORTH);
        
        // Center Panel - Submissions Table
        createSubmissionsTable();
        JScrollPane scrollPane = new JScrollPane(submissionsTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Student Submissions"));
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Status Panel
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.setBackground(new Color(240, 248, 255));
        lblStatus = new JLabel(" ");
        lblStatus.setFont(new Font("Arial", Font.ITALIC, 12));
        lblStatus.setForeground(Color.BLUE);
        statusPanel.add(lblStatus);
        mainPanel.add(statusPanel, BorderLayout.SOUTH);
        
        // Bottom Panel - Actions
        JPanel bottomPanel = createActionPanel();
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        setVisible(true);
    }
    
    private JPanel createFilterPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(46, 134, 171)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Course Label and Combo
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Select Course:"), gbc);
        
        gbc.gridx = 1;
        cmbCourse = new JComboBox<>();
        cmbCourse.setPreferredSize(new Dimension(250, 30));
        panel.add(cmbCourse, gbc);
        
        // Assignment Label and Combo
        gbc.gridx = 2;
        panel.add(new JLabel("Select Assignment:"), gbc);
        
        gbc.gridx = 3;
        cmbAssignment = new JComboBox<>();
        cmbAssignment.setPreferredSize(new Dimension(250, 30));
        panel.add(cmbAssignment, gbc);
        
        // Load Button
        gbc.gridx = 4;
        btnLoadSubmissions = createActionButton("Load Submissions", new Color(46, 134, 171));
        panel.add(btnLoadSubmissions, gbc);
        
        // Load courses and assignments
        loadCourses();
        cmbCourse.addActionListener(e -> loadAssignments());
        btnLoadSubmissions.addActionListener(e -> loadSubmissions());
        
        return panel;
    }
    
    private void createSubmissionsTable() {
        String[] columns = {"Submission ID", "Student Name", "Assignment Title", 
                           "Submission Date", "File Path", "Grade", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5; // Only grade column is editable
            }
        };
        submissionsTable = new JTable(tableModel);
        submissionsTable.setRowHeight(35);
        
        // Set column widths
        submissionsTable.getColumnModel().getColumn(0).setPreferredWidth(80);
        submissionsTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        submissionsTable.getColumnModel().getColumn(2).setPreferredWidth(200);
        submissionsTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        submissionsTable.getColumnModel().getColumn(4).setPreferredWidth(200);
        submissionsTable.getColumnModel().getColumn(5).setPreferredWidth(80);
        submissionsTable.getColumnModel().getColumn(6).setPreferredWidth(100);
    }
    
    private JPanel createActionPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panel.setBackground(new Color(240, 248, 255));
        
        btnSaveGrade = createActionButton("Save Grades", new Color(46, 204, 113));
        JButton btnRefresh = createActionButton("Refresh", new Color(241, 196, 15));
        JButton btnClose = createActionButton("Close", new Color(220, 60, 50));
        
        panel.add(btnSaveGrade);
        panel.add(btnRefresh);
        panel.add(btnClose);
        
        btnSaveGrade.addActionListener(e -> saveGrades());
        btnRefresh.addActionListener(e -> {
            loadAssignments();
            loadSubmissions();
        });
        btnClose.addActionListener(e -> dispose());
        
        return panel;
    }
    
    private JButton createActionButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    private void loadCourses() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT course_id, course_name FROM courses";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            cmbCourse.removeAllItems();
            cmbCourse.addItem("-- Select Course --");
            while (rs.next()) {
                cmbCourse.addItem(rs.getInt("course_id") + " - " + rs.getString("course_name"));
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading courses: " + e.getMessage());
        }
    }
    
    private void loadAssignments() {
        cmbAssignment.removeAllItems();
        cmbAssignment.addItem("-- Select Assignment --");
        
        if (cmbCourse.getSelectedItem() == null || 
            cmbCourse.getSelectedItem().toString().equals("-- Select Course --")) {
            return;
        }
        
        String selected = cmbCourse.getSelectedItem().toString();
        int courseId = Integer.parseInt(selected.split(" - ")[0]);
        
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT assignment_id, title FROM assignments WHERE course_id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, courseId);
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
                cmbAssignment.addItem(rs.getInt("assignment_id") + " - " + rs.getString("title"));
            }
            
            if (cmbAssignment.getItemCount() == 1) {
                lblStatus.setText("⚠️ No assignments found for this course.");
            } else {
                lblStatus.setText("✅ " + (cmbAssignment.getItemCount() - 1) + " assignments available.");
            }
            
            rs.close();
            pst.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
            lblStatus.setText("Error loading assignments: " + e.getMessage());
        }
    }
    
    private void loadSubmissions() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Check if assignment is selected
        if (cmbAssignment.getSelectedItem() == null || 
            cmbAssignment.getSelectedItem().toString().equals("-- Select Assignment --")) {
            lblStatus.setText("⚠️ Please select an assignment first!");
            return;
        }
        
        String selected = cmbAssignment.getSelectedItem().toString();
        int assignmentId = Integer.parseInt(selected.split(" - ")[0]);
        String assignmentTitle = selected.split(" - ")[1];
        
        lblStatus.setText("Loading submissions for: " + assignmentTitle + "...");
        
        try {
            Connection con = DBConnection.getConnection();
            
            // First, check if there are any submissions
            String countSql = "SELECT COUNT(*) FROM submissions WHERE assignment_id = ?";
            PreparedStatement countPst = con.prepareStatement(countSql);
            countPst.setInt(1, assignmentId);
            ResultSet countRs = countPst.executeQuery();
            countRs.next();
            int submissionCount = countRs.getInt(1);
            countRs.close();
            countPst.close();
            
            if (submissionCount == 0) {
                lblStatus.setText("⚠️ No submissions found for '" + assignmentTitle + "'. Students haven't submitted yet.");
                // Add a message row in the table
                tableModel.addRow(new Object[]{"-", "No submissions", assignmentTitle, "-", "-", "-", "No Data"});
                return;
            }
            
            // Load actual submissions
            String sql = "SELECT s.submission_id, st.name, a.title, s.submission_date, " +
                        "IFNULL(s.file_path, 'No file') as file_path, " +
                        "IFNULL(s.grade, '') as grade, " +
                        "IFNULL(s.status, 'Pending') as status " +
                        "FROM submissions s " +
                        "JOIN students st ON s.student_id = st.student_id " +
                        "JOIN assignments a ON s.assignment_id = a.assignment_id " +
                        "WHERE s.assignment_id = ? " +
                        "ORDER BY s.submission_date DESC";
            
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, assignmentId);
            ResultSet rs = pst.executeQuery();
            
            int rowCount = 0;
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("submission_id"),
                    rs.getString("name"),
                    rs.getString("title"),
                    rs.getDate("submission_date"),
                    rs.getString("file_path"),
                    rs.getString("grade"),
                    rs.getString("status")
                });
                rowCount++;
            }
            
            lblStatus.setText("✅ Loaded " + rowCount + " submission(s) for '" + assignmentTitle + "'");
            
            rs.close();
            pst.close();
            con.close();
            
        } catch (SQLException e) {
            e.printStackTrace();
            lblStatus.setText("❌ Error loading submissions: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Database Error: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            lblStatus.setText("❌ Error parsing assignment ID");
            e.printStackTrace();
        }
    }
    
    private void saveGrades() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, 
                "No submissions to save!", 
                "Warning", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Save all grade changes?\nThis will update the grades for all displayed submissions.", 
            "Confirm Save", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            int updatedCount = 0;
            
            try {
                Connection con = DBConnection.getConnection();
                String sql = "UPDATE submissions SET grade = ?, status = ? WHERE submission_id = ?";
                PreparedStatement pst = con.prepareStatement(sql);
                
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    // Skip the "No submissions" message row
                    if (tableModel.getValueAt(i, 0).toString().equals("-")) {
                        continue;
                    }
                    
                    int submissionId = Integer.parseInt(tableModel.getValueAt(i, 0).toString());
                    String grade = (String) tableModel.getValueAt(i, 5);
                    String status = (grade != null && !grade.trim().isEmpty()) ? "Graded" : "Pending";
                    
                    pst.setString(1, grade);
                    pst.setString(2, status);
                    pst.setInt(3, submissionId);
                    pst.addBatch();
                    updatedCount++;
                }
                
                if (updatedCount > 0) {
                    int[] results = pst.executeBatch();
                    JOptionPane.showMessageDialog(this, 
                        "✅ " + updatedCount + " submission(s) graded successfully!", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    loadSubmissions(); // Refresh the table
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "No valid submissions to update.", 
                        "Info", 
                        JOptionPane.INFORMATION_MESSAGE);
                }
                
                pst.close();
                con.close();
                
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, 
                    "Error saving grades: " + e.getMessage(), 
                    "Database Error", 
                    JOptionPane.ERROR_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, 
                    "Error parsing submission ID", 
                    "Data Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}