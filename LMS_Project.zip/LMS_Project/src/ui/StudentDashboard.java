package ui;

import javax.swing.*;
import java.awt.*;

public class StudentDashboard extends JFrame {

    private int studentId = 1; // This should come from login session

    public StudentDashboard() {
        initializeUI();
    }
    
    public StudentDashboard(int id) {
        this.studentId = id;
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("Smart Learning Management System - Student Dashboard");
        setSize(550, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(new Color(240, 248, 255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Title
        JLabel lblTitle = new JLabel("📚 SMART LEARNING MANAGEMENT SYSTEM");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitle.setForeground(new Color(46, 204, 113));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(lblTitle, gbc);
        
        JLabel lblSubtitle = new JLabel("Student Dashboard");
        lblSubtitle.setFont(new Font("Arial", Font.ITALIC, 12));
        lblSubtitle.setForeground(Color.GRAY);
        lblSubtitle.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 1;
        mainPanel.add(lblSubtitle, gbc);
        
        // Separator
        JSeparator separator = new JSeparator();
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(separator, gbc);
        
        // Welcome Message
        JLabel lblWelcome = new JLabel("Welcome, Student!");
        lblWelcome.setFont(new Font("Arial", Font.BOLD, 14));
        lblWelcome.setForeground(new Color(46, 204, 113));
        gbc.gridy = 3;
        mainPanel.add(lblWelcome, gbc);
        
        // Course Management Section
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        JLabel lblCourseSection = new JLabel("📚 MY COURSES");
        lblCourseSection.setFont(new Font("Arial", Font.BOLD, 14));
        lblCourseSection.setForeground(new Color(46, 204, 113));
        mainPanel.add(lblCourseSection, gbc);
        
        // Course Buttons
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = 2;
        JButton btnViewCourses = createStudentButton("📖 View My Courses");
        JButton btnBrowseCourses = createStudentButton("🔍 Browse Available Courses");
        
        gbc.gridy = 5;
        mainPanel.add(btnViewCourses, gbc);
        gbc.gridy = 6;
        mainPanel.add(btnBrowseCourses, gbc);
        
        // Assignment Section
        gbc.gridy = 7;
        JLabel lblAssignmentSection = new JLabel("📝 ASSIGNMENTS");
        lblAssignmentSection.setFont(new Font("Arial", Font.BOLD, 14));
        lblAssignmentSection.setForeground(new Color(46, 204, 113));
        mainPanel.add(lblAssignmentSection, gbc);
        
        // Assignment Buttons
        JButton btnViewAssignments = createStudentButton("📋 View Assignments");
        
        gbc.gridy = 8;
        mainPanel.add(btnViewAssignments, gbc);
        
        // Logout Button
        gbc.gridy = 9;
        JButton btnLogout = createLogoutButton();
        mainPanel.add(btnLogout, gbc);
        
        // ========== ACTION LISTENERS ==========
        
        // View Courses - Opens existing ViewCoursesForm
        btnViewCourses.addActionListener(e -> {
            try {
                new ViewCoursesForm();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error opening courses: " + ex.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Browse Available Courses
        btnBrowseCourses.addActionListener(e -> {
            try {
                new BrowseCoursesForm();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error opening course browser: " + ex.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // View Assignments
        btnViewAssignments.addActionListener(e -> {
            try {
                new ViewAssignmentsForm();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error opening assignments: " + ex.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        add(mainPanel);
        setVisible(true);
    }
    
    private JButton createStudentButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setBackground(new Color(46, 204, 113));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(12, 10, 12, 10));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(64, 224, 128));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(46, 204, 113));
            }
        });
        
        return button;
    }
    
    private JButton createLogoutButton() {
        JButton button = new JButton("🚪 LOGOUT");
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(new Color(220, 60, 50));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(12, 10, 12, 10));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(240, 80, 70));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(220, 60, 50));
            }
        });
        
        button.addActionListener(e -> {
            int option = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to logout?",
                    "Logout Confirmation",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
                    
            if (option == JOptionPane.YES_OPTION) {
                dispose();
                new LoginForm();
            }
        });
        
        return button;
    }
}