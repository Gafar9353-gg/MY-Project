package ui;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class ViewStudentProgressForm extends JFrame {
    
    private JTable progressTable;
    private DefaultTableModel tableModel;
    private JComboBox<String> cmbCourse;
    private JLabel lblAverageGrade, lblTotalStudents, lblPassRate;
    
    public ViewStudentProgressForm() {
        setTitle("Student Progress Report");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 248, 255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Top Panel
        JPanel topPanel = createTopPanel();
        mainPanel.add(topPanel, BorderLayout.NORTH);
        
        // Stats Panel
        JPanel statsPanel = createStatsPanel();
        mainPanel.add(statsPanel, BorderLayout.CENTER);
        
        // Table Panel
        createProgressTable();
        JScrollPane scrollPane = new JScrollPane(progressTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Student Performance Details"));
        mainPanel.add(scrollPane, BorderLayout.SOUTH);
        
        add(mainPanel);
        setVisible(true);
    }
    
    private JPanel createTopPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        panel.add(new JLabel("Select Course:"));
        cmbCourse = new JComboBox<>();
        cmbCourse.setPreferredSize(new Dimension(250, 30));
        panel.add(cmbCourse);
        
        JButton btnLoad = new JButton("Load Progress");
        btnLoad.setBackground(new Color(46, 134, 171));
        btnLoad.setForeground(Color.WHITE);
        btnLoad.addActionListener(e -> loadProgress());
        panel.add(btnLoad);
        
        loadCourses();
        
        return panel;
    }
    
    private JPanel createStatsPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 3, 20, 20));
        panel.setBackground(new Color(240, 248, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Average Grade Card
        JPanel avgCard = createStatCard("Average Grade", "0%", new Color(46, 134, 171));
        lblAverageGrade = (JLabel) avgCard.getComponent(1);
        panel.add(avgCard);
        
        // Total Students Card
        JPanel studentsCard = createStatCard("Total Students", "0", new Color(46, 204, 113));
        lblTotalStudents = (JLabel) studentsCard.getComponent(1);
        panel.add(studentsCard);
        
        // Pass Rate Card
        JPanel passCard = createStatCard("Pass Rate", "0%", new Color(241, 196, 15));
        lblPassRate = (JLabel) passCard.getComponent(1);
        panel.add(passCard);
        
        return panel;
    }
    
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel lblTitle = new JLabel(title, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 14));
        
        JLabel lblValue = new JLabel(value, SwingConstants.CENTER);
        lblValue.setFont(new Font("Arial", Font.BOLD, 24));
        lblValue.setForeground(color);
        
        card.add(lblTitle, BorderLayout.NORTH);
        card.add(lblValue, BorderLayout.CENTER);
        
        return card;
    }
    
    private void createProgressTable() {
        String[] columns = {"Student ID", "Student Name", "Enrolled Course", 
                           "Assignments Completed", "Average Grade", "Status"};
        tableModel = new DefaultTableModel(columns, 0);
        progressTable = new JTable(tableModel);
        progressTable.setRowHeight(30);
    }
    
    private void loadCourses() {
        try {
            Connection con = DBConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT course_id, course_name FROM courses");
            
            while (rs.next()) {
                cmbCourse.addItem(rs.getInt("course_id") + " - " + rs.getString("course_name"));
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void loadProgress() {
        if (cmbCourse.getSelectedItem() == null) return;
        
        String selected = cmbCourse.getSelectedItem().toString();
        int courseId = Integer.parseInt(selected.split(" - ")[0]);
        
        tableModel.setRowCount(0);
        
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT s.student_id, s.name, " +
                        "COUNT(DISTINCT sub.submission_id) as completed, " +
                        "AVG(CAST(sub.grade AS DECIMAL)) as avg_grade " +
                        "FROM students s " +
                        "LEFT JOIN submissions sub ON s.student_id = sub.student_id " +
                        "LEFT JOIN assignments a ON sub.assignment_id = a.assignment_id " +
                        "WHERE a.course_id = ? OR a.course_id IS NULL " +
                        "GROUP BY s.student_id, s.name";
            
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, courseId);
            ResultSet rs = pst.executeQuery();
            
            int totalStudents = 0;
            double totalGrades = 0;
            int passedCount = 0;
            
            while (rs.next()) {
                int studentId = rs.getInt("student_id");
                String name = rs.getString("name");
                int completed = rs.getInt("completed");
                double avgGrade = rs.getDouble("avg_grade");
                String status = avgGrade >= 60 ? "Passing" : (completed > 0 ? "At Risk" : "Not Started");
                
                tableModel.addRow(new Object[]{
                    studentId, name, selected.split(" - ")[1], completed,
                    avgGrade > 0 ? String.format("%.1f", avgGrade) + "%" : "N/A", status
                });
                
                totalStudents++;
                if (avgGrade > 0) totalGrades += avgGrade;
                if (avgGrade >= 60) passedCount++;
            }
            
            // Update stats
            lblTotalStudents.setText(String.valueOf(totalStudents));
            if (totalStudents > 0) {
                lblAverageGrade.setText(String.format("%.1f%%", totalGrades / totalStudents));
                lblPassRate.setText(String.format("%.1f%%", (passedCount * 100.0 / totalStudents)));
            }
            
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}