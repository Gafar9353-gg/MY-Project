package ui;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.io.*;
import db.DBConnection;

public class SubmitAssignmentForm extends JFrame {
    
    private JComboBox<String> cmbCourse;
    private JComboBox<String> cmbAssignment;
    private JTextArea txtDescription;
    private JLabel lblFileName;
    private JButton btnBrowse, btnSubmit;
    private String selectedFilePath = "";
    private int studentId = 1; // This should come from login session
    
    public SubmitAssignmentForm() {
        setTitle("Submit Assignment");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(new Color(240, 248, 255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Title
        JLabel lblTitle = new JLabel("Assignment Submission Form", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitle.setForeground(new Color(46, 204, 113));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(lblTitle, gbc);
        
        // Course Selection
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        mainPanel.add(new JLabel("Select Course:"), gbc);
        
        gbc.gridx = 1;
        cmbCourse = new JComboBox<>();
        cmbCourse.setPreferredSize(new Dimension(300, 30));
        cmbCourse.addActionListener(e -> loadAssignments());
        mainPanel.add(cmbCourse, gbc);
        
        // Assignment Selection
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(new JLabel("Select Assignment:"), gbc);
        
        gbc.gridx = 1;
        cmbAssignment = new JComboBox<>();
        cmbAssignment.setPreferredSize(new Dimension(300, 30));
        mainPanel.add(cmbAssignment, gbc);
        
        // Description
        gbc.gridx = 0;
        gbc.gridy = 3;
        mainPanel.add(new JLabel("Your Notes:"), gbc);
        
        gbc.gridx = 1;
        txtDescription = new JTextArea(5, 30);
        txtDescription.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JScrollPane scrollPane = new JScrollPane(txtDescription);
        mainPanel.add(scrollPane, gbc);
        
        // File Selection
        gbc.gridx = 0;
        gbc.gridy = 4;
        mainPanel.add(new JLabel("Assignment File:"), gbc);
        
        gbc.gridx = 1;
        JPanel filePanel = new JPanel(new BorderLayout(5, 5));
        lblFileName = new JLabel("No file selected");
        lblFileName.setFont(new Font("Arial", Font.ITALIC, 12));
        lblFileName.setForeground(Color.GRAY);
        
        btnBrowse = new JButton("Browse...");
        btnBrowse.setBackground(new Color(46, 204, 113));
        btnBrowse.setForeground(Color.WHITE);
        btnBrowse.addActionListener(e -> browseFile());
        
        filePanel.add(lblFileName, BorderLayout.CENTER);
        filePanel.add(btnBrowse, BorderLayout.EAST);
        mainPanel.add(filePanel, gbc);
        
        // Submit Button
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        btnSubmit = new JButton("📤 Submit Assignment");
        btnSubmit.setBackground(new Color(46, 204, 113));
        btnSubmit.setForeground(Color.WHITE);
        btnSubmit.setFont(new Font("Arial", Font.BOLD, 14));
        btnSubmit.setPreferredSize(new Dimension(200, 40));
        btnSubmit.addActionListener(e -> submitAssignment());
        mainPanel.add(btnSubmit, gbc);
        
        loadCourses();
        
        add(mainPanel);
        setVisible(true);
    }
    
    private void loadCourses() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT DISTINCT c.course_id, c.course_name " +
                        "FROM courses c " +
                        "JOIN assignments a ON c.course_id = a.course_id";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            cmbCourse.removeAllItems();
            while (rs.next()) {
                cmbCourse.addItem(rs.getInt("course_id") + " - " + rs.getString("course_name"));
            }
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void loadAssignments() {
        if (cmbCourse.getSelectedItem() == null) return;
        
        String selected = cmbCourse.getSelectedItem().toString();
        int courseId = Integer.parseInt(selected.split(" - ")[0]);
        
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT assignment_id, title FROM assignments WHERE course_id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, courseId);
            ResultSet rs = pst.executeQuery();
            
            cmbAssignment.removeAllItems();
            while (rs.next()) {
                cmbAssignment.addItem(rs.getInt("assignment_id") + " - " + rs.getString("title"));
            }
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void browseFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Assignment File");
        int result = fileChooser.showOpenDialog(this);
        
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            selectedFilePath = selectedFile.getAbsolutePath();
            lblFileName.setText(selectedFile.getName());
            lblFileName.setForeground(Color.BLACK);
        }
    }
    
    private void submitAssignment() {
        if (cmbAssignment.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select an assignment!");
            return;
        }
        
        if (selectedFilePath.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a file to submit!");
            return;
        }
        
        String selected = cmbAssignment.getSelectedItem().toString();
        int assignmentId = Integer.parseInt(selected.split(" - ")[0]);
        String description = txtDescription.getText();
        
        try {
            Connection con = DBConnection.getConnection();
            
            // Check if already submitted
            String checkSql = "SELECT * FROM submissions WHERE assignment_id = ? AND student_id = ?";
            PreparedStatement checkPst = con.prepareStatement(checkSql);
            checkPst.setInt(1, assignmentId);
            checkPst.setInt(2, studentId);
            ResultSet rs = checkPst.executeQuery();
            
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, 
                    "You have already submitted this assignment!", 
                    "Duplicate Submission", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Insert submission
            String sql = "INSERT INTO submissions (assignment_id, student_id, submission_date, " +
                        "file_path, description, status) VALUES (?, ?, CURDATE(), ?, ?, 'Submitted')";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, assignmentId);
            pst.setInt(2, studentId);
            pst.setString(3, selectedFilePath);
            pst.setString(4, description);
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(this, 
                "Assignment submitted successfully!\nFile: " + selectedFilePath, 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
            
            // Clear form
            txtDescription.setText("");
            selectedFilePath = "";
            lblFileName.setText("No file selected");
            lblFileName.setForeground(Color.GRAY);
            
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error submitting assignment: " + e.getMessage());
        }
    }
}