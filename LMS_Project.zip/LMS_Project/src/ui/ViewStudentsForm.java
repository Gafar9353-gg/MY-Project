package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

import db.DBConnection;

public class ViewStudentsForm extends JFrame {

    JTable table;
    DefaultTableModel model;

    public ViewStudentsForm() {

        setTitle("View Students");
        setSize(600, 400);
        setLocationRelativeTo(null);

        model = new DefaultTableModel();

        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Email");
        model.addColumn("Semester");

        table = new JTable(model);

        JScrollPane scrollPane =
                new JScrollPane(table);

        add(scrollPane);

        loadStudents();

        setVisible(true);
    }

    private void loadStudents() {

        try {

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "SELECT * FROM students";

            PreparedStatement pst =
                    con.prepareStatement(sql);

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                model.addRow(new Object[]{
                        rs.getInt("student_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getInt("semester")
                });
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}