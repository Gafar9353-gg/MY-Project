package ui;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class BrowseCoursesForm extends JFrame {
    
    private JTable coursesTable;
    private DefaultTableModel tableModel;
    private JTextField txtSearch;
    private int studentId = 1; // This should come from login session
    
    public BrowseCoursesForm() {
        setTitle("Browse Available Courses");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 248, 255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Top Panel - Search
        JPanel topPanel = createSearchPanel();
        mainPanel.add(topPanel, BorderLayout.NORTH);
        
        // Center Panel - Courses Table
        createCoursesTable();
        JScrollPane scrollPane = new JScrollPane(coursesTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Available Courses"));
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Bottom Panel - Actions
        JPanel bottomPanel = createActionPanel();
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        loadCourses();
        
        add(mainPanel);
        setVisible(true);
    }
    
    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        panel.add(new JLabel("Search:"));
        txtSearch = new JTextField(20);
        panel.add(txtSearch);
        
        JButton btnSearch = new JButton("🔍 Search");
        btnSearch.setBackground(new Color(46, 204, 113));
        btnSearch.setForeground(Color.WHITE);
        btnSearch.addActionListener(e -> searchCourses());
        panel.add(btnSearch);
        
        JButton btnRefresh = new JButton("🔄 Refresh");
        btnRefresh.addActionListener(e -> loadCourses());
        panel.add(btnRefresh);
        
        return panel;
    }
    
    private void createCoursesTable() {
        String[] columns = {"Course ID", "Course Name", "Faculty", "Enrolled", "Action"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4; // Only action column is editable
            }
        };
        coursesTable = new JTable(tableModel);
        coursesTable.setRowHeight(40);
        
        // Add button renderer
        coursesTable.getColumn("Action").setCellRenderer(new ButtonRenderer());
        coursesTable.getColumn("Action").setCellEditor(new ButtonEditor(new JCheckBox()));
    }
    
    private JPanel createActionPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.setBackground(new Color(240, 248, 255));
        
        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(e -> dispose());
        panel.add(btnClose);
        
        return panel;
    }
    
    private void loadCourses() {
        tableModel.setRowCount(0);
        
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT c.course_id, c.course_name, f.name as faculty_name, " +
                        "(SELECT COUNT(*) FROM students WHERE student_id = ?) as enrolled " +
                        "FROM courses c " +
                        "LEFT JOIN faculty f ON c.faculty_id = f.faculty_id";
            
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, studentId);
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("course_id"),
                    rs.getString("course_name"),
                    rs.getString("faculty_name"),
                    rs.getInt("enrolled"),
                    "Enroll"
                });
            }
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void searchCourses() {
        String searchTerm = txtSearch.getText().toLowerCase();
        tableModel.setRowCount(0);
        
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT c.course_id, c.course_name, f.name as faculty_name " +
                        "FROM courses c " +
                        "LEFT JOIN faculty f ON c.faculty_id = f.faculty_id " +
                        "WHERE LOWER(c.course_name) LIKE ? OR LOWER(f.name) LIKE ?";
            
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, "%" + searchTerm + "%");
            pst.setString(2, "%" + searchTerm + "%");
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("course_id"),
                    rs.getString("course_name"),
                    rs.getString("faculty_name"),
                    "Enroll"
                });
            }
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void enrollCourse(int courseId) {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "INSERT INTO enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, CURDATE())";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, studentId);
            pst.setInt(2, courseId);
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Successfully enrolled in course!");
            loadCourses();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error enrolling: " + e.getMessage());
        }
    }
    
    // Button Renderer for Action Column
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }
        
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "Enroll" : value.toString());
            setBackground(new Color(46, 204, 113));
            setForeground(Color.WHITE);
            return this;
        }
    }
    
    // Button Editor for Action Column
    class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private String label;
        private boolean isPushed;
        private int selectedRow;
        
        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }
        
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            label = (value == null) ? "Enroll" : value.toString();
            button.setText(label);
            isPushed = true;
            selectedRow = row;
            return button;
        }
        
        public Object getCellEditorValue() {
            if (isPushed) {
                int courseId = (int) coursesTable.getValueAt(selectedRow, 0);
                enrollCourse(courseId);
            }
            isPushed = false;
            return label;
        }
    }
}