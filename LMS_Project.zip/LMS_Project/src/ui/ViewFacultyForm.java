package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

import db.DBConnection;

public class ViewFacultyForm extends JFrame {

    JTable table;
    DefaultTableModel model;

    public ViewFacultyForm() {

        setTitle("View Faculty");
        setSize(600,400);

        model = new DefaultTableModel();

        model.addColumn("Faculty ID");
        model.addColumn("Name");
        model.addColumn("Email");

        table = new JTable(model);

        add(new JScrollPane(table));

        loadFaculty();

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadFaculty() {

        try {

            Connection con =
                    DBConnection.getConnection();

            ResultSet rs =
                    con.createStatement()
                            .executeQuery(
                                    "SELECT * FROM faculty");

            while(rs.next()) {

                model.addRow(new Object[] {
                        rs.getInt("faculty_id"),
                        rs.getString("name"),
                        rs.getString("email")
                });
            }

        } catch(Exception e) {

            e.printStackTrace();
        }
    }
}