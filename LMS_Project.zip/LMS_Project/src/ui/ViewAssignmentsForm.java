package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

import db.DBConnection;

public class ViewAssignmentsForm extends JFrame {

    public ViewAssignmentsForm() {

        setTitle("View Assignments");
        setSize(700,400);

        DefaultTableModel model =
                new DefaultTableModel();

        model.addColumn("ID");
        model.addColumn("Title");
        model.addColumn("Description");

        JTable table =
                new JTable(model);

        add(new JScrollPane(table));

        try {

            Connection con =
                    DBConnection.getConnection();

            ResultSet rs =
                    con.createStatement()
                    .executeQuery(
                    "SELECT * FROM assignments");

            while(rs.next()) {

                model.addRow(new Object[] {
                    rs.getInt("assignment_id"),
                    rs.getString("title"),
                    rs.getString("description")
                });
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        setLocationRelativeTo(null);
        setVisible(true);
    }
}