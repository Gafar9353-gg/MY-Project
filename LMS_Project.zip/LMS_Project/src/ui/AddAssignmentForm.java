package ui;

import javax.swing.*;

import dao.AssignmentDAO;
import model.Assignment;

public class AddAssignmentForm extends JFrame {

    JTextField txtTitle;
    JTextArea txtDescription;

    public AddAssignmentForm() {

        setTitle("Add Assignment");
        setSize(500,400);
        setLayout(null);

        JLabel lblTitle =
            new JLabel("Title");

        lblTitle.setBounds(30,30,100,25);
        add(lblTitle);

        txtTitle = new JTextField();

        txtTitle.setBounds(120,30,250,25);
        add(txtTitle);

        JLabel lblDesc =
            new JLabel("Description");

        lblDesc.setBounds(30,80,100,25);
        add(lblDesc);

        txtDescription =
            new JTextArea();

        JScrollPane scroll =
            new JScrollPane(txtDescription);

        scroll.setBounds(120,80,250,120);
        add(scroll);

        JButton btnSave =
            new JButton("Save");

        btnSave.setBounds(170,250,120,35);
        add(btnSave);

        btnSave.addActionListener(
                e -> saveAssignment());

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void saveAssignment() {

        Assignment assignment =
            new Assignment(
                txtTitle.getText(),
                txtDescription.getText()
            );

        AssignmentDAO dao =
            new AssignmentDAO();

        if(dao.addAssignment(assignment)) {

            JOptionPane.showMessageDialog(
                this,
                "Assignment Added Successfully");
               txtTitle.setText("");
                txtDescription.setText("");
                
    

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Failed");
        }
    }
}