package ui;

import javax.swing.*;

import dao.CourseDAO;
import model.Course;

public class AddCourseForm extends JFrame {

    JTextField txtCourse;
    JButton btnSave;

    public AddCourseForm() {

        setTitle("Add Course");

        setSize(350,200);

        setLayout(null);

        JLabel lblCourse =
                new JLabel("Course Name");

        lblCourse.setBounds(30,40,100,25);

        add(lblCourse);

        txtCourse =
                new JTextField();

        txtCourse.setBounds(140,40,150,25);

        add(txtCourse);

        btnSave =
                new JButton("Save");

        btnSave.setBounds(120,100,100,30);

        add(btnSave);

        btnSave.addActionListener(
                e -> saveCourse());

        setLocationRelativeTo(null);

        setVisible(true);
    }

    private void saveCourse() {

        String name =
                txtCourse.getText();

        Course course =
                new Course(name);

        CourseDAO dao =
                new CourseDAO();

        if(dao.addCourse(course)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Course Added Successfully");

            txtCourse.setText("");

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Failed");
        }
    }
}