package ui;

import javax.swing.*;
import java.awt.*;

public class FacultyDashboard extends JFrame {

    private String facultyName = "Faculty Member"; // You can set this from login
    private int facultyId = 1; // This should come from login session

    public FacultyDashboard() {
        this("Faculty Member"); // Default name
    }
    
    public FacultyDashboard(String name) {
        this.facultyName = name;
        initializeUI();
    }
    
    public FacultyDashboard(String name, int id) {
        this.facultyName = name;
        this.facultyId = id;
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("Smart Learning Management System - Faculty Dashboard");
        setSize(900, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Main Panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 248, 255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Header Panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Center Panel with Dashboard Content
        JPanel centerPanel = createDashboardPanel();
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        
        // Footer Panel
        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        setVisible(true);
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(46, 134, 171)); // Teal color for faculty
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Title and welcome message
        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 5, 5));
        titlePanel.setBackground(new Color(46, 134, 171));
        
        JLabel lblTitle = new JLabel("Smart Learning Management System", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);
        
        JLabel lblSubtitle = new JLabel("Faculty Control Panel", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Arial", Font.PLAIN, 14));
        lblSubtitle.setForeground(new Color(240, 248, 255));
        
        titlePanel.add(lblTitle);
        titlePanel.add(lblSubtitle);
        
        // Faculty info panel
        JPanel facultyInfoPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        facultyInfoPanel.setBackground(new Color(46, 134, 171));
        
        JLabel lblFaculty = new JLabel("👨‍🏫 Welcome, " + facultyName);
        lblFaculty.setFont(new Font("Arial", Font.ITALIC, 12));
        lblFaculty.setForeground(Color.WHITE);
        facultyInfoPanel.add(lblFaculty);
        
        headerPanel.add(titlePanel, BorderLayout.CENTER);
        headerPanel.add(facultyInfoPanel, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    private JPanel createDashboardPanel() {
        JPanel centerPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        centerPanel.setBackground(new Color(240, 248, 255));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Course Management Card
        centerPanel.add(createCourseCard());
        
        // Assignment Management Card
        centerPanel.add(createAssignmentCard());
        
        // Grading Card
        centerPanel.add(createGradingCard());
        
        // Quick Stats Card
        centerPanel.add(createStatsCard());
        
        return centerPanel;
    }
    
    private JPanel createCourseCard() {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(46, 134, 171), 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        // Card Title
        JLabel lblTitle = new JLabel("📚 Course Management", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitle.setForeground(new Color(46, 134, 171));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        card.add(lblTitle, BorderLayout.NORTH);
        
        // Buttons Panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 10, 15));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JButton btnViewCourses = createFacultyButton("📖 View My Courses", 
            "View all courses assigned to you");
        btnViewCourses.addActionListener(e -> new ViewCoursesForm());
        
        buttonPanel.add(btnViewCourses);
        
        card.add(buttonPanel, BorderLayout.CENTER);
        
        return card;
    }
    
    private JPanel createAssignmentCard() {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(46, 134, 171), 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        // Card Title
        JLabel lblTitle = new JLabel("📝 Assignment Management", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitle.setForeground(new Color(46, 134, 171));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        card.add(lblTitle, BorderLayout.NORTH);
        
        // Buttons Panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 10, 15));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JButton btnAddAssignment = createFacultyButton("✏️ Create Assignment", 
            "Add new assignment for students");
        btnAddAssignment.addActionListener(e -> new AddAssignmentForm());
        
        JButton btnViewAssignments = createFacultyButton("📋 View All Assignments", 
            "View all created assignments");
        btnViewAssignments.addActionListener(e -> new ViewAssignmentsForm());
        
        buttonPanel.add(btnAddAssignment);
        buttonPanel.add(btnViewAssignments);
        
        card.add(buttonPanel, BorderLayout.CENTER);
        
        return card;
    }
    
    private JPanel createGradingCard() {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(46, 134, 171), 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        // Card Title
        JLabel lblTitle = new JLabel("🎯 Grading & Assessment", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitle.setForeground(new Color(46, 134, 171));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        card.add(lblTitle, BorderLayout.NORTH);
        
        // Buttons Panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 10, 15));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JButton btnGradeSubmissions = createFacultyButton("✅ Grade Submissions", 
            "Review and grade student submissions");
        btnGradeSubmissions.addActionListener(e -> {
            try {
                new GradeSubmissionsForm();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error opening grading form: " + ex.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton btnViewProgress = createFacultyButton("📊 View Student Progress", 
            "Track student performance");
        btnViewProgress.addActionListener(e -> {
            try {
                new ViewStudentProgressForm();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error opening progress view: " + ex.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        buttonPanel.add(btnGradeSubmissions);
        buttonPanel.add(btnViewProgress);
        
        card.add(buttonPanel, BorderLayout.CENTER);
        
        return card;
    }
    
    private JPanel createStatsCard() {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(new Color(46, 134, 171));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(46, 134, 171), 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        // Card Title
        JLabel lblTitle = new JLabel("📊 Quick Stats", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        card.add(lblTitle, BorderLayout.NORTH);
        
        // Stats Panel
        JPanel statsPanel = new JPanel(new GridLayout(4, 1, 10, 15));
        statsPanel.setBackground(new Color(46, 134, 171));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JLabel lblCourses = new JLabel("📖 Active Courses: --", SwingConstants.CENTER);
        lblCourses.setFont(new Font("Arial", Font.BOLD, 14));
        lblCourses.setForeground(Color.WHITE);
        
        JLabel lblAssignments = new JLabel("📝 Total Assignments: --", SwingConstants.CENTER);
        lblAssignments.setFont(new Font("Arial", Font.BOLD, 14));
        lblAssignments.setForeground(Color.WHITE);
        
        JLabel lblSubmissions = new JLabel("📤 Pending Submissions: --", SwingConstants.CENTER);
        lblSubmissions.setFont(new Font("Arial", Font.BOLD, 14));
        lblSubmissions.setForeground(Color.WHITE);
        
        JLabel lblStudents = new JLabel("👨‍🎓 Total Students: --", SwingConstants.CENTER);
        lblStudents.setFont(new Font("Arial", Font.BOLD, 14));
        lblStudents.setForeground(Color.WHITE);
        
        statsPanel.add(lblCourses);
        statsPanel.add(lblAssignments);
        statsPanel.add(lblSubmissions);
        statsPanel.add(lblStudents);
        
        // Load actual stats from database
        loadStats(lblCourses, lblAssignments, lblSubmissions, lblStudents);
        
        card.add(statsPanel, BorderLayout.CENTER);
        
        return card;
    }
    
    private void loadStats(JLabel lblCourses, JLabel lblAssignments, 
                          JLabel lblSubmissions, JLabel lblStudents) {
        try {
            java.sql.Connection con = db.DBConnection.getConnection();
            
            // Get courses count for this faculty
            String courseSql = "SELECT COUNT(*) FROM courses WHERE faculty_id = ?";
            java.sql.PreparedStatement pst = con.prepareStatement(courseSql);
            pst.setInt(1, facultyId);
            java.sql.ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                lblCourses.setText("📖 Active Courses: " + rs.getInt(1));
            }
            
            // Get assignments count
            String assignmentSql = "SELECT COUNT(*) FROM assignments a " +
                                  "JOIN courses c ON a.course_id = c.course_id " +
                                  "WHERE c.faculty_id = ?";
            pst = con.prepareStatement(assignmentSql);
            pst.setInt(1, facultyId);
            rs = pst.executeQuery();
            if (rs.next()) {
                lblAssignments.setText("📝 Total Assignments: " + rs.getInt(1));
            }
            
            // Get pending submissions count
            String submissionSql = "SELECT COUNT(*) FROM submissions s " +
                                  "JOIN assignments a ON s.assignment_id = a.assignment_id " +
                                  "JOIN courses c ON a.course_id = c.course_id " +
                                  "WHERE c.faculty_id = ? AND (s.status = 'Pending' OR s.grade IS NULL)";
            pst = con.prepareStatement(submissionSql);
            pst.setInt(1, facultyId);
            rs = pst.executeQuery();
            if (rs.next()) {
                lblSubmissions.setText("📤 Pending Submissions: " + rs.getInt(1));
            }
            
            // Get students count
            String studentSql = "SELECT COUNT(DISTINCT s.student_id) FROM submissions s " +
                               "JOIN assignments a ON s.assignment_id = a.assignment_id " +
                               "JOIN courses c ON a.course_id = c.course_id " +
                               "WHERE c.faculty_id = ?";
            pst = con.prepareStatement(studentSql);
            pst.setInt(1, facultyId);
            rs = pst.executeQuery();
            if (rs.next()) {
                lblStudents.setText("👨‍🎓 Total Students: " + rs.getInt(1));
            }
            
            rs.close();
            pst.close();
            con.close();
            
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
    }
    
    private JButton createFacultyButton(String text, String tooltip) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setBackground(new Color(46, 134, 171));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(12, 10, 12, 10));
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(52, 152, 219));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(46, 134, 171));
            }
        });
        
        return button;
    }
    
    private JPanel createFooterPanel() {
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(new Color(46, 134, 171));
        footerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JLabel lblFooter = new JLabel("© 2024 Smart Learning Management System - Faculty Portal");
        lblFooter.setFont(new Font("Arial", Font.PLAIN, 11));
        lblFooter.setForeground(Color.WHITE);
        footerPanel.add(lblFooter, BorderLayout.WEST);
        
        // Logout Button
        JButton btnLogout = createLogoutButton();
        footerPanel.add(btnLogout, BorderLayout.EAST);
        
        return footerPanel;
    }
    
    private JButton createLogoutButton() {
        JButton button = new JButton("🚪 Logout");
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBackground(new Color(220, 60, 50));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(240, 80, 70));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(220, 60, 50));
            }
        });
        
        button.addActionListener(e -> {
            int option = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to logout?",
                    "Logout Confirmation",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
                    
            if (option == JOptionPane.YES_OPTION) {
                dispose();
                new LoginForm();
            }
        });
        
        return button;
    }
}