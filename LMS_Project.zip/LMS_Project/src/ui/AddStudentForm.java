package ui;

import javax.swing.*;

import dao.StudentDAO;
import model.Student;

public class AddStudentForm extends JFrame {

    JTextField txtName;
    JTextField txtEmail;
    JTextField txtSemester;

    JButton btnSave;

    public AddStudentForm() {

        setTitle("Add Student");

        setSize(400,300);

        setLayout(null);

        JLabel lblName =
            new JLabel("Name");

        lblName.setBounds(50,50,100,25);

        add(lblName);

        txtName = new JTextField();

        txtName.setBounds(150,50,150,25);

        add(txtName);

        JLabel lblEmail =
            new JLabel("Email");

        lblEmail.setBounds(50,100,100,25);

        add(lblEmail);

        txtEmail = new JTextField();

        txtEmail.setBounds(150,100,150,25);

        add(txtEmail);

        JLabel lblSemester =
            new JLabel("Semester");

        lblSemester.setBounds(50,150,100,25);

        add(lblSemester);

        txtSemester = new JTextField();

        txtSemester.setBounds(150,150,150,25);

        add(txtSemester);

        btnSave = new JButton("Save");

        btnSave.setBounds(150,200,100,30);

        add(btnSave);

        btnSave.addActionListener(e -> saveStudent());

        setLocationRelativeTo(null);

        setVisible(true);
    }

   private void saveStudent() {

    try {

        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();

        int semester =
                Integer.parseInt(txtSemester.getText().trim());

        Student student =
                new Student(name, email, semester);

        StudentDAO dao =
                new StudentDAO();

        if (dao.addStudent(student)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Student Added Successfully");

            txtName.setText("");
            txtEmail.setText("");
            txtSemester.setText("");

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Failed To Add Student");
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Error: " + e.getMessage());
    }
}
}