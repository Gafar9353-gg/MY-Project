package ui;

import javax.swing.*;
import java.awt.*;

public class AdminDashboard extends JFrame {

    public AdminDashboard() {

        setTitle("Smart Learning Management System - Admin Dashboard");
        setSize(900, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Main Panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(240, 248, 255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Header Panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Center Panel with Cards Layout for Dashboard Sections
        JPanel centerPanel = createDashboardPanel();
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        
        // Footer Panel
        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        setVisible(true);
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Title and welcome message
        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 5, 5));
        titlePanel.setBackground(new Color(70, 130, 180));
        
        JLabel lblTitle = new JLabel("Smart Learning Management System", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);
        
        JLabel lblSubtitle = new JLabel("Administrator Control Panel", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Arial", Font.PLAIN, 14));
        lblSubtitle.setForeground(new Color(240, 248, 255));
        
        titlePanel.add(lblTitle);
        titlePanel.add(lblSubtitle);
        
        // Admin info panel
        JPanel adminInfoPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        adminInfoPanel.setBackground(new Color(70, 130, 180));
        
        JLabel lblAdmin = new JLabel("Welcome, Administrator");
        lblAdmin.setFont(new Font("Arial", Font.ITALIC, 12));
        lblAdmin.setForeground(Color.WHITE);
        adminInfoPanel.add(lblAdmin);
        
        headerPanel.add(titlePanel, BorderLayout.CENTER);
        headerPanel.add(adminInfoPanel, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    private JPanel createDashboardPanel() {
        JPanel centerPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        centerPanel.setBackground(new Color(240, 248, 255));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Student Management Card
        centerPanel.add(createCardPanel("Student Management", 
            new String[]{"Add Student", "View Students"},
            new String[]{"➕ Add New Student", "📋 View All Students"},
            e -> new AddStudentForm(),
            e -> new ViewStudentsForm()
        ));
        
        // Course Management Card
        centerPanel.add(createCardPanel("Course Management", 
            new String[]{"Add Course", "View Courses"},
            new String[]{"📚 Create New Course", "📖 Browse All Courses"},
            e -> new AddCourseForm(),
            e -> new ViewCoursesForm()
        ));
        
        // Faculty Management Card
        centerPanel.add(createCardPanel("Faculty Management", 
            new String[]{"Add Faculty", "View Faculty"},
            new String[]{"👨‍🏫 Register Faculty", "👥 Faculty Directory"},
            e -> new AddFacultyForm(),
            e -> new ViewFacultyForm()
        ));
        
        // Assignment Management Card
        centerPanel.add(createCardPanel("Assignment Management", 
            new String[]{"Add Assignment", "View Assignments"},
            new String[]{"📝 Create Assignment", "📊 All Assignments"},
            e -> new AddAssignmentForm(),
            e -> new ViewAssignmentsForm()
        ));
        
        return centerPanel;
    }
    
    private JPanel createCardPanel(String title, String[] buttonTexts, String[] tooltips, 
                                   java.awt.event.ActionListener action1, 
                                   java.awt.event.ActionListener action2) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        // Card Title
        JLabel lblTitle = new JLabel(title, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitle.setForeground(new Color(70, 130, 180));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        card.add(lblTitle, BorderLayout.NORTH);
        
        // Buttons Panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 10, 15));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JButton btn1 = createStyledButton(buttonTexts[0], tooltips[0]);
        btn1.addActionListener(action1);
        
        JButton btn2 = createStyledButton(buttonTexts[1], tooltips[1]);
        btn2.addActionListener(action2);
        
        buttonPanel.add(btn1);
        buttonPanel.add(btn2);
        
        card.add(buttonPanel, BorderLayout.CENTER);
        
        return card;
    }
    
    private JButton createStyledButton(String text, String tooltip) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(12, 10, 12, 10));
        button.setToolTipText(tooltip);
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(100, 149, 237));
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(70, 130, 180));
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
        
        return button;
    }
    
    private JPanel createFooterPanel() {
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(new Color(70, 130, 180));
        footerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JLabel lblFooter = new JLabel("© 2024 Smart Learning Management System - All Rights Reserved");
        lblFooter.setFont(new Font("Arial", Font.PLAIN, 11));
        lblFooter.setForeground(Color.WHITE);
        footerPanel.add(lblFooter, BorderLayout.WEST);
        
        // Logout Button
        JButton btnLogout = new JButton("🚪 Logout");
        btnLogout.setFont(new Font("Arial", Font.BOLD, 12));
        btnLogout.setBackground(new Color(220, 60, 50));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btnLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnLogout.setBackground(new Color(240, 80, 70));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnLogout.setBackground(new Color(220, 60, 50));
            }
        });
        
        btnLogout.addActionListener(e -> {
            int option = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to logout?",
                    "Logout Confirmation",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
                    
            if (option == JOptionPane.YES_OPTION) {
                dispose();
                new LoginForm();
            }
        });
        
        footerPanel.add(btnLogout, BorderLayout.EAST);
        
        return footerPanel;
    }
}