package ui;

import javax.swing.*;

import dao.FacultyDAO;
import model.Faculty;

public class AddFacultyForm extends JFrame {

    JTextField txtName;
    JTextField txtEmail;

    JButton btnSave;

    public AddFacultyForm() {

        setTitle("Add Faculty");

        setSize(400,300);
        setLayout(null);

        JLabel lblName = new JLabel("Name");
        lblName.setBounds(50,50,100,25);
        add(lblName);

        txtName = new JTextField();
        txtName.setBounds(150,50,150,25);
        add(txtName);

        JLabel lblEmail = new JLabel("Email");
        lblEmail.setBounds(50,100,100,25);
        add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(150,100,150,25);
        add(txtEmail);

        btnSave = new JButton("Save");
        btnSave.setBounds(150,180,100,30);
        add(btnSave);

        btnSave.addActionListener(
                e -> saveFaculty());

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void saveFaculty() {

        Faculty faculty =
                new Faculty(
                        txtName.getText(),
                        txtEmail.getText());

        FacultyDAO dao =
                new FacultyDAO();

        if(dao.addFaculty(faculty)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Faculty Added Successfully");
                      txtName.setText("");
    txtEmail.setText("");

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Failed");
        }
    }
}