package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import db.DBConnection;

public class LoginForm extends JFrame {

    JTextField txtUsername;
    JPasswordField txtPassword;
    JButton btnLogin;
    JButton btnClear;
    JLabel lblStatus;

    public LoginForm() {

        setTitle("Smart Learning Management System - Login");
        setSize(450, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Set frame icon (optional - add your own icon if available)
        // setIconImage(Toolkit.getDefaultToolkit().getImage("icon.png"));
        
        // Main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        mainPanel.setBackground(new Color(240, 248, 255)); // AliceBlue background
        
        // Header Panel with Title
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180)); // SteelBlue
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel titleLabel = new JLabel("Smart Learning Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        
        JLabel subtitleLabel = new JLabel("Login to Your Account");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitleLabel.setForeground(new Color(240, 248, 255));
        
        headerPanel.setLayout(new BorderLayout(5, 5));
        headerPanel.add(titleLabel, BorderLayout.NORTH);
        headerPanel.add(subtitleLabel, BorderLayout.SOUTH);
        
        // Center Panel - Login Form
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(240, 248, 255));
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 20, 30, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Username Label and Field
        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        formPanel.add(lblUsername, gbc);
        
        txtUsername = new JTextField(15);
        txtUsername.setFont(new Font("Arial", Font.PLAIN, 14));
        txtUsername.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(169, 169, 169)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(txtUsername, gbc);
        
        // Password Label and Field
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        formPanel.add(lblPassword, gbc);
        
        txtPassword = new JPasswordField(15);
        txtPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        txtPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(169, 169, 169)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(txtPassword, gbc);
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        buttonPanel.setBackground(new Color(240, 248, 255));
        
        btnLogin = new JButton("Login");
        btnLogin.setBackground(new Color(70, 130, 180));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFont(new Font("Arial", Font.BOLD, 14));
        btnLogin.setPreferredSize(new Dimension(100, 35));
        btnLogin.setFocusPainted(false);
        btnLogin.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        
        btnClear = new JButton("Clear");
        btnClear.setBackground(new Color(220, 220, 220));
        btnClear.setForeground(Color.BLACK);
        btnClear.setFont(new Font("Arial", Font.PLAIN, 14));
        btnClear.setPreferredSize(new Dimension(100, 35));
        btnClear.setFocusPainted(false);
        
        buttonPanel.add(btnLogin);
        buttonPanel.add(btnClear);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(buttonPanel, gbc);
        
        // Status Label
        lblStatus = new JLabel(" ");
        lblStatus.setFont(new Font("Arial", Font.ITALIC, 12));
        lblStatus.setForeground(new Color(255, 69, 0));
        lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Footer Panel
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(70, 130, 180));
        footerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel footerLabel = new JLabel("© 2024 Smart Learning Management System");
        footerLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);
        
        // Assemble main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        // Add status label to south (below footer)
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBackground(new Color(240, 248, 255));
        statusPanel.add(lblStatus, BorderLayout.CENTER);
        statusPanel.add(footerPanel, BorderLayout.SOUTH);
        
        mainPanel.add(statusPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Action Listeners
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
        
        btnClear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });
        
        // Press Enter key to login
        txtPassword.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
        
        // Mouse hover effects for buttons
        btnLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnLogin.setBackground(new Color(100, 149, 237));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnLogin.setBackground(new Color(70, 130, 180));
            }
        });
        
        btnClear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnClear.setBackground(new Color(200, 200, 200));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnClear.setBackground(new Color(220, 220, 220));
            }
        });
        
        setVisible(true);
    }
    
    private void clearFields() {
        txtUsername.setText("");
        txtPassword.setText("");
        lblStatus.setText(" ");
        txtUsername.requestFocus();
    }

    private void login() {

        String username = txtUsername.getText().trim();
        String password = String.valueOf(txtPassword.getPassword());

        // Basic validation
        if (username.isEmpty() || password.isEmpty()) {
            lblStatus.setText("❌ Please enter both username and password");
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter both username and password",
                    "Validation Error",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        lblStatus.setText("⏳ Logging in...");
        btnLogin.setEnabled(false);

        try {

            Connection con = DBConnection.getConnection();

            // Get user with role information
            String sql = "SELECT * FROM users WHERE username=? AND password=?";

            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, username);
            pst.setString(2, password);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                String role = rs.getString("role");
                
                lblStatus.setText("✅ Login Successful! Redirecting...");
                
                JOptionPane.showMessageDialog(
                        this,
                        "Welcome " + username + "!\nRole: " + role,
                        "Login Successful",
                        JOptionPane.INFORMATION_MESSAGE
                );

                // Close login window
                dispose();

                // Redirect based on role
                if (role.equals("ADMIN")) {
                    new AdminDashboard();
                    
                } else if (role.equals("FACULTY")) {
                    new FacultyDashboard();
                    
                } else if (role.equals("STUDENT")) {
                    new StudentDashboard();
                    
                } else {
                    JOptionPane.showMessageDialog(
                            null,
                            "Unknown role: " + role,
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }

            } else {
                lblStatus.setText("❌ Invalid username or password");
                JOptionPane.showMessageDialog(
                        this,
                        "Invalid Username or Password",
                        "Login Failed",
                        JOptionPane.ERROR_MESSAGE
                );
                // Clear password field
                txtPassword.setText("");
                txtPassword.requestFocus();
                btnLogin.setEnabled(true);
            }
            
            rs.close();
            pst.close();

        } catch (SQLException ex) {
            lblStatus.setText("❌ Database connection error");
            JOptionPane.showMessageDialog(
                    this,
                    "Database Error: " + ex.getMessage(),
                    "Connection Error",
                    JOptionPane.ERROR_MESSAGE
            );
            ex.printStackTrace();
            btnLogin.setEnabled(true);
        } catch (Exception ex) {
            lblStatus.setText("❌ Error: " + ex.getMessage());
            JOptionPane.showMessageDialog(
                    this,
                    "Error: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            ex.printStackTrace();
            btnLogin.setEnabled(true);
        }
    }

    // Main method for testing
    public static void main(String[] args) {
        // Set Look and Feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Run login form on EDT
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginForm();
            }
        });
    }
}