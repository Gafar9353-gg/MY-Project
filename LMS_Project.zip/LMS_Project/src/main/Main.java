package main;

import ui.LoginForm;

public class Main {

    public static void main(String[] args) {

        new LoginForm();

    }
}