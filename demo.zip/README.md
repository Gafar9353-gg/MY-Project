# Interactive 3D portfolio website design

Created with [Omma](https://omma.build)

## Setup

Open `index.html` in your browser, or:

```bash
npx serve .
```
