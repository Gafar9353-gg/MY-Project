// ==================== HELPER FUNCTIONS ====================
function getCurrentUser() {
    return localStorage.getItem("currentUser");
}

function getCurrentRole() {
    return localStorage.getItem("currentRole");
}

function getAssignments() {
    return JSON.parse(localStorage.getItem("assignments")) || [];
}

function saveAssignments(assignments) {
    localStorage.setItem("assignments", JSON.stringify(assignments));
}

function generatePlagiarism() {
    return Math.floor(Math.random() * 100);
}

// ==================== UPDATE USER DISPLAY ====================
function updateUserDisplay() {
    const userNameSpan = document.getElementById("currentUserName");
    if (userNameSpan) {
        const currentUser = getCurrentUser();
        const currentRole = getCurrentRole();
        if (currentUser && currentRole) {
            userNameSpan.textContent = `${currentUser} (${currentRole})`;
        } else {
            userNameSpan.textContent = "Guest";
        }
    }
}

// ==================== LOGIN ====================
const VALID_CREDENTIALS = {
    student: [
        { username: "naveen", password: "student123" },
        { username: "priya", password: "student456" },
        { username: "rahul", password: "student789" }
    ],
    faculty: [
        { username: "prof_smith", password: "faculty123" },
        { username: "dr_sharma", password: "faculty456" }
    ]
};

document.addEventListener("DOMContentLoaded", () => {
    updateUserDisplay();

    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value.trim();
            const role = document.getElementById("role").value;

            if (!username || !password) return alert("Enter username and password");
            if (!role) return alert("Select role");

            let isValid = false;
            if (role === "student") {
                isValid = VALID_CREDENTIALS.student.some(c => c.username === username && c.password === password);
                if (!isValid) return alert("Invalid Student! Try naveen/student123");
            } else {
                isValid = VALID_CREDENTIALS.faculty.some(c => c.username === username && c.password === password);
                if (!isValid) return alert("Invalid Faculty! Try prof_smith/faculty123");
            }

            localStorage.setItem("currentUser", username);
            localStorage.setItem("currentRole", role);
            window.location.href = role === "student" ? "student-dashboard.html" : "faculty-dashboard.html";
        });
    }

    if (document.getElementById("studentCards")) loadStudentDashboard();
    if (document.getElementById("facultyTable")) loadFacultyDashboard();
    if (document.getElementById("reportTableBody")) loadReportPage();
    if (document.getElementById("submissionChart")) loadStatisticsPage();
});

// ==================== STUDENT DASHBOARD ====================
function loadStudentDashboard() {
    const currentUser = getCurrentUser();
    let assignments = getAssignments();
    let userAssignments = assignments.filter(a => a.student === currentUser);

    // Cards
    document.getElementById("totalAssignments").innerText = userAssignments.length;
    let submittedCount = userAssignments.length;
    document.getElementById("submittedCount").innerText = submittedCount;
    let pendingCount = userAssignments.filter(a => a.customStatus === "Pending").length;
    document.getElementById("pendingCount").innerText = pendingCount;
    let avgOriginality = userAssignments.length ? Math.round(userAssignments.reduce((s, a) => s + (100 - a.plagiarism), 0) / userAssignments.length) : 0;
    document.getElementById("avgScore").innerText = avgOriginality + "%";

    // Profile
    document.getElementById("profileName").innerText = currentUser || "Student";
    document.getElementById("profileEmail").innerText = currentUser + "@example.com";

    // History Table
    const tbody = document.getElementById("assignmentTable");
    if (tbody) {
        tbody.innerHTML = "";
        userAssignments.forEach(a => {
            let statusClass = "btn-primary";
            let statusText = a.customStatus || "Pending";
            if (statusText === "Approved") statusClass = "btn-success";
            else if (statusText === "Review") statusClass = "btn-primary";
            else if (statusText === "High Risk") statusClass = "btn-danger";
            let comments = a.comments || "—";
            tbody.innerHTML += `
                <tr>
                    <td>${a.subject}</td>
                    <td>${a.assignment}</td>
                    <td>${a.date}</td>
                    <td>${a.plagiarism}%</td>
                    <td><button class="btn ${statusClass}">${statusText}</button></td>
                    <td>${comments}</td>
                </tr>
            `;
        });
    }

    // Upload Form
    const form = document.getElementById("assignmentForm");
    if (form) {
        const newForm = form.cloneNode(true);
        form.parentNode.replaceChild(newForm, form);
        newForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const subject = document.getElementById("subject").value;
            const assignment = document.getElementById("assignment").value;
            const fileInput = document.getElementById("fileUpload");
            let fileName = fileInput.files[0] ? fileInput.files[0].name : "No file";

            let newAssignment = {
                id: Date.now(),
                student: currentUser,
                subject: subject,
                assignment: assignment,
                file: fileName,
                date: new Date().toLocaleDateString(),
                plagiarism: generatePlagiarism(),
                customStatus: "Pending",
                comments: ""
            };
            let all = getAssignments();
            all.push(newAssignment);
            saveAssignments(all);
            alert(`Assignment Submitted!\nPlagiarism Score: ${newAssignment.plagiarism}%`);
            newForm.reset();
            loadStudentDashboard();
        });
    }
}

// ==================== FACULTY DASHBOARD ====================
function loadFacultyDashboard() {
    let assignments = getAssignments();

    document.getElementById("totalSubmissions").innerText = assignments.length;
    let highRisk = assignments.filter(a => a.customStatus === "High Risk").length;
    document.getElementById("highRiskCases").innerText = highRisk;
    let reviewed = assignments.filter(a => a.customStatus && a.customStatus !== "Pending").length;
    let reviewedPercent = assignments.length ? Math.round((reviewed / assignments.length) * 100) : 0;
    document.getElementById("reviewedAssignments").innerText = reviewedPercent + "%";
    let avgOriginality = assignments.length ? Math.round(assignments.reduce((s, a) => s + (100 - a.plagiarism), 0) / assignments.length) : 0;
    document.getElementById("avgOriginality").innerText = avgOriginality + "%";

    const tbody = document.getElementById("facultyTable");
    if (tbody) {
        function renderTable() {
            assignments = getAssignments();
            tbody.innerHTML = "";
            if (assignments.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No assignments submitted yet.</td></tr>';
                return;
            }
            assignments.forEach(a => {
                let riskClass = a.plagiarism >= 60 ? "high" : (a.plagiarism >= 30 ? "medium" : "low");
                let btnClass = "btn-secondary";
                let btnText = a.customStatus || "Pending";
                if (btnText === "Approved") btnClass = "btn-success";
                else if (btnText === "Review") btnClass = "btn-primary";
                else if (btnText === "High Risk") btnClass = "btn-danger";
                
                tbody.innerHTML += `
                    <tr>
                        <td>${a.student}</td>
                        <td>${a.subject}</td>
                        <td>${a.assignment}</td>
                        <td><div class="progress"><div class="progress-bar ${riskClass}" style="width:${a.plagiarism}%">${a.plagiarism}%</div></div></td>
                        <td><button class="btn ${btnClass} status-btn" data-id="${a.id}">${btnText}</button></td>
                        <td><button class="btn btn-primary review-btn" data-id="${a.id}">Review</button></td>
                    </tr>
                `;
            });

            document.querySelectorAll(".review-btn").forEach(btn => {
                btn.addEventListener("click", (e) => {
                    let id = parseInt(btn.getAttribute("data-id"));
                    let assignment = getAssignments().find(a => a.id === id);
                    if (assignment) openReviewModal(assignment);
                });
            });
        }
        renderTable();

        const searchInput = document.getElementById("searchInput");
        if (searchInput) {
            searchInput.addEventListener("keyup", function () {
                let filter = this.value.toLowerCase();
                let rows = tbody.querySelectorAll("tr");
                rows.forEach(row => {
                    let text = row.cells[0].innerText.toLowerCase();
                    row.style.display = text.includes(filter) ? "" : "none";
                });
            });
        }

        const analysisForm = document.getElementById("analysisForm");
        if (analysisForm) {
            const newAnalysisForm = analysisForm.cloneNode(true);
            analysisForm.parentNode.replaceChild(newAnalysisForm, analysisForm);
            newAnalysisForm.addEventListener("submit", (e) => {
                e.preventDefault();
                let student = document.getElementById("studentName").value;
                let subject = document.getElementById("subjectName").value;
                let assignment = document.getElementById("assignmentName").value;
                let newAnalysis = {
                    id: Date.now(),
                    student: student,
                    subject: subject,
                    assignment: assignment,
                    file: "Faculty Review",
                    date: new Date().toLocaleDateString(),
                    plagiarism: generatePlagiarism(),
                    customStatus: "Pending",
                    comments: ""
                };
                let all = getAssignments();
                all.push(newAnalysis);
                saveAssignments(all);
                alert(`Analysis done! Plagiarism: ${newAnalysis.plagiarism}%`);
                newAnalysisForm.reset();
                loadFacultyDashboard();
            });
        }
    }
}

// ==================== MODAL FUNCTIONS ====================
function openReviewModal(assignment) {
    document.getElementById("modalStudent").innerText = assignment.student;
    document.getElementById("modalSubject").innerText = assignment.subject;
    document.getElementById("modalAssignment").innerText = assignment.assignment;
    document.getElementById("modalPlagiarism").innerText = assignment.plagiarism;
    document.getElementById("modalFile").innerText = assignment.file || "No file";
    document.getElementById("modalStatus").value = assignment.customStatus || "Pending";
    document.getElementById("modalComments").value = assignment.comments || "";
    
    const modal = document.getElementById("reviewModal");
    modal.style.display = "flex";
    
    const saveBtn = document.getElementById("saveReviewBtn");
    const closeBtn = document.getElementById("closeModalBtn");
    
    const saveHandler = () => {
        let newStatus = document.getElementById("modalStatus").value;
        let newComments = document.getElementById("modalComments").value;
        let all = getAssignments();
        let updated = all.map(a => {
            if (a.id === assignment.id) {
                a.customStatus = newStatus;
                a.comments = newComments;
            }
            return a;
        });
        saveAssignments(updated);
        modal.style.display = "none";
        loadFacultyDashboard();
    };
    
    const closeHandler = () => {
        modal.style.display = "none";
        saveBtn.removeEventListener("click", saveHandler);
        closeBtn.removeEventListener("click", closeHandler);
    };
    
    saveBtn.removeEventListener("click", saveHandler);
    closeBtn.removeEventListener("click", closeHandler);
    saveBtn.addEventListener("click", saveHandler);
    closeBtn.addEventListener("click", closeHandler);
    
    window.onclick = (e) => {
        if (e.target === modal) closeHandler();
    };
}

// ==================== PLAGIARISM REPORT PAGE ====================
function loadReportPage() {
    let assignments = getAssignments();
    let role = getCurrentRole();
    let currentUser = getCurrentUser();
    let data = role === "student" ? assignments.filter(a => a.student === currentUser) : assignments;

    const tbody = document.getElementById("reportTableBody");
    if (tbody) {
        tbody.innerHTML = "";
        data.forEach(a => {
            let originality = 100 - a.plagiarism;
            let btnClass = "btn-secondary";
            let btnText = a.customStatus || "Pending";
            if (btnText === "Approved") btnClass = "btn-success";
            else if (btnText === "Review") btnClass = "btn-primary";
            else if (btnText === "High Risk") btnClass = "btn-danger";
            tbody.innerHTML += `
                <tr>
                    <td>${a.student}</td>
                    <td>${a.subject}</td>
                    <td>${a.assignment}</td>
                    <td>${a.plagiarism}%</td>
                    <td>${originality}%</td>
                    <td><button class="btn ${btnClass}">${btnText}</button></td>
                </tr>
            `;
        });
    }

    if (document.getElementById("totalAssignmentsReport")) {
        document.getElementById("totalAssignmentsReport").innerText = data.length;
        let avgOrig = data.length ? Math.round(data.reduce((s, a) => s + (100 - a.plagiarism), 0) / data.length) : 0;
        document.getElementById("avgOriginalityReport").innerText = avgOrig + "%";
        let highRiskCount = data.filter(a => a.customStatus === "High Risk").length;
        document.getElementById("highRiskReports").innerText = highRiskCount;
        let reviewedCount = data.filter(a => a.customStatus && a.customStatus !== "Pending").length;
        document.getElementById("reviewedReports").innerText = Math.round((reviewedCount / data.length) * 100) || 0 + "%";
    }
}

// ==================== STATISTICS PAGE ====================
let submissionChartInstance = null;
let plagiarismChartInstance = null;

function loadStatisticsPage() {
    let assignments = getAssignments();
    let total = assignments.length;
    let highRisk = assignments.filter(a => a.customStatus === "High Risk").length;
    let avgPlag = total ? Math.round(assignments.reduce((s, a) => s + a.plagiarism, 0) / total) : 0;
    let avgOriginality = 100 - avgPlag;
    let reviewed = assignments.filter(a => a.customStatus && a.customStatus !== "Pending").length;
    let reviewedPercent = total ? Math.round((reviewed / total) * 100) : 0;

    document.getElementById("statTotal").innerText = total;
    document.getElementById("statAvgOriginality").innerText = avgOriginality + "%";
    document.getElementById("statHighRisk").innerText = highRisk;
    document.getElementById("statReviewed").innerText = reviewedPercent + "%";

    let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"];
    let monthlyCounts = [0, 0, 0, 0, 0, 0];
    assignments.forEach(a => {
        let dateParts = a.date.split("/");
        if (dateParts.length === 3) {
            let month = parseInt(dateParts[1]) - 1;
            if (month >= 0 && month < 6) monthlyCounts[month]++;
        }
    });
    
    const ctx1 = document.getElementById("submissionChart").getContext("2d");
    if (submissionChartInstance) submissionChartInstance.destroy();
    submissionChartInstance = new Chart(ctx1, {
        type: "bar",
        data: { labels: months, datasets: [{ label: "Assignments", data: monthlyCounts, backgroundColor: "#2563eb" }] }
    });

    let lowRisk = assignments.filter(a => a.plagiarism < 30).length;
    let mediumRisk = assignments.filter(a => a.plagiarism >= 30 && a.plagiarism < 60).length;
    const ctx2 = document.getElementById("plagiarismChart").getContext("2d");
    if (plagiarismChartInstance) plagiarismChartInstance.destroy();
    plagiarismChartInstance = new Chart(ctx2, {
        type: "doughnut",
        data: { labels: ["Low Risk", "Medium Risk", "High Risk"], datasets: [{ data: [lowRisk, mediumRisk, highRisk], backgroundColor: ["#22c55e", "#f59e0b", "#ef4444"] }] }
    });
}

// ==================== LOGOUT (FIXED – does NOT clear assignments) ====================
function logout() {
    localStorage.removeItem("currentUser");
    localStorage.removeItem("currentRole");
    window.location.href = "index.html";
}